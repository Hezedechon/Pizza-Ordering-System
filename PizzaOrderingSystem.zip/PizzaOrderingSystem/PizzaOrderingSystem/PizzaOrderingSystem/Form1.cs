﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PizzaOrderingSystem
{
    public partial class Form1 : Form
    {
        int totalAmount = 0;
        public static Form1 _instance;
       
        Form2 form2;
        public Form1()
        {
            InitializeComponent();
            form2 = new Form2();
            radioSizeSmall.Checked = true;
            radioSauceRanch.Checked = true;
            radioCrustClassic.Checked = true;
            textTotalAmount.Enabled = false;
            textTotalAmount2.Enabled = false;
            _instance = this;
            
            

        }

        private void button7_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader("login.txt");
            string readLine = sr.ReadLine();

            string[] readLineArray = readLine.Split(',');

            if (textUserName.Text == readLineArray[0] && textPassword.Text == readLineArray[1])
            {
                form2.Show();
            }
            else
            {
                MessageBox.Show("Please enter valid username or password!");
                textUserName.Text = textPassword.Text = "";
            }
                

            sr.Close();
            //if (textUserName.Text == "berk" && textPassword.Text == "123456")
            //{

            //    form2.Show();
            //}
        }
        public ListViewItem pizzaSize = new ListViewItem();
        public ListViewItem pizzaSauce = new ListViewItem();
        public ListViewItem pizzaCrust = new ListViewItem();
        public ListViewItem snack = new ListViewItem();
        //public ListViewItem customerInfo = new ListViewItem();
        public void ChooseSize()
        {
             
            if(radioSizeSmall.Checked == true)
            {
                pizzaSize = new ListViewItem("Small Size");
                pizzaSize.SubItems.Add("");
                pizzaSize.SubItems.Add("10");
                listOrder.Items.Add(pizzaSize);
            }
            else if (radioSizeMedium.Checked == true)
            {
                pizzaSize = new ListViewItem("Medium Size");
                pizzaSize.SubItems.Add("");
                pizzaSize.SubItems.Add("15");
                listOrder.Items.Add(pizzaSize);
            }
            else if (radioSizeLarge.Checked == true)
            {
                pizzaSize = new ListViewItem("Large Size");
                pizzaSize.SubItems.Add("");
                pizzaSize.SubItems.Add("20");
                listOrder.Items.Add(pizzaSize);
            }
            else if (radioSizeKing.Checked == true)
            {
                pizzaSize = new ListViewItem("King Size");
                pizzaSize.SubItems.Add("");
                pizzaSize.SubItems.Add("25");
                listOrder.Items.Add(pizzaSize);

            }
        }
        public void ChooseSauce()
        {
            

            if(radioSauceRanch.Checked == true)
            {
                pizzaSauce = new ListViewItem("Ranch Sauce");
                pizzaSauce.SubItems.Add("");
                pizzaSauce.SubItems.Add("3");
                listOrder.Items.Add(pizzaSauce);
            }
            else if (radioSauceBarbeque.Checked == true)
            {
                pizzaSauce = new ListViewItem("Barbeque Sauce");
                pizzaSauce.SubItems.Add("");
                pizzaSauce.SubItems.Add("3");
                listOrder.Items.Add(pizzaSauce);
            }
            else if (radioSaucePesto.Checked == true)
            {
                pizzaSauce = new ListViewItem("Pesto Sauce");
                pizzaSauce.SubItems.Add("");
                pizzaSauce.SubItems.Add("3");
                listOrder.Items.Add(pizzaSauce);
            }
            else if (radioSauceBerk.Checked == true)
            {
                pizzaSauce = new ListViewItem("Berk's Special Sauce");
                pizzaSauce.SubItems.Add("");
                pizzaSauce.SubItems.Add("3");
                listOrder.Items.Add(pizzaSauce);
            }
        }
        public void ChooseCrust()
        {
           
            if (radioCrustClassic.Checked == true)
            {
                pizzaCrust = new ListViewItem("Classic Crust");
                pizzaCrust.SubItems.Add("");
                pizzaCrust.SubItems.Add("1");
                listOrder.Items.Add(pizzaCrust);
            }
            else if (radioCrustDouble.Checked == true)
            {
                pizzaCrust = new ListViewItem("Double Cheesy Crust");
                pizzaCrust.SubItems.Add("");
                pizzaCrust.SubItems.Add("2");
                listOrder.Items.Add(pizzaCrust);
            }
            else if (radioCrustSausage.Checked == true)
            {
                pizzaCrust = new ListViewItem("Sausage Crust");
                pizzaCrust.SubItems.Add("");
                pizzaCrust.SubItems.Add("3");
                listOrder.Items.Add(pizzaCrust);
            }
            else if (radioCrustSquare.Checked == true)
            {
                pizzaCrust = new ListViewItem("Square Crust");
                pizzaCrust.SubItems.Add("");
                pizzaCrust.SubItems.Add("2");
                listOrder.Items.Add(pizzaCrust);
            }
        }
        public void ChooseSnack()
        {
            if (checkFrenchF.Checked == true)
            {
                snack = new ListViewItem("French Fries");
                snack.SubItems.Add("");
                snack.SubItems.Add("5");
                listOrder.Items.Add(snack);
            }
            if (checkOnionR.Checked == true)
            {
                snack = new ListViewItem("Onion Rings");
                snack.SubItems.Add("");
                snack.SubItems.Add("5");
                listOrder.Items.Add(snack);
            }
            if (checkChickenW.Checked == true)
            {
                snack = new ListViewItem("Chicken Wings");
                snack.SubItems.Add("");
                snack.SubItems.Add("8");
                listOrder.Items.Add(snack);
            }
            if (checkBuffaloW.Checked == true)
            {
                snack = new ListViewItem("Buffalo Wings");
                snack.SubItems.Add("");
                snack.SubItems.Add("8");
                listOrder.Items.Add(snack);
            }
            if (checkCheesyS.Checked == true)
            {
                snack = new ListViewItem("Cheesy Stick");
                snack.SubItems.Add("");
                snack.SubItems.Add("6");
                listOrder.Items.Add(snack);
            }
            if (checkTurkishB.Checked == true)
            {
                snack = new ListViewItem("Turkish Bacon");
                snack.SubItems.Add("");
                snack.SubItems.Add("15");
                listOrder.Items.Add(snack);
            }

        }
        public void ChooseToppings()
        {
            if (checkMozzarella.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Mozzarella");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkOnion.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Onion");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkBeef.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Beef");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkPepper.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Pepper");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkPepperoni.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Pepperoni");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkMushroom.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Mushroom");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkJalepeno.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Jalepeno");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkAnchovies.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Anchovies");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkChicken.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Chicken");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkPineApple.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Pine " +
                    "Apple");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkGorgonzola.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Gorgonzola");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkAsiago.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Asiago");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkSpinach.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Spinach");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkBacon.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Bacon");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkShrimp.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Shrimp");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkBelPaese.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Bel Paese");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkOlive.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Olive");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
            if (checkTuna.Checked == true)
            {
                ListViewItem topping = new ListViewItem("Tuna");
                topping.SubItems.Add("");
                topping.SubItems.Add("1");
                listOrder.Items.Add(topping);
            }
        }
        public void ChooseDrinks()
        {
            if (textCokeQ.Text != "0")
            {
                ListViewItem drink = new ListViewItem("Coke");
                drink.SubItems.Add(textCokeQ.Text);
                int totalAmount = Convert.ToInt32(textCokeQ.Text) * 3;
                drink.SubItems.Add(totalAmount.ToString());
                listOrder.Items.Add(drink);
            }
            if (textDietCokeQ.Text != "0")
            {
                ListViewItem drink = new ListViewItem("Diet Coke");
                drink.SubItems.Add(textDietCokeQ.Text);
                int totalAmount = Convert.ToInt32(textDietCokeQ.Text) * 3;
                drink.SubItems.Add(totalAmount.ToString());
                listOrder.Items.Add(drink);
            }
            if (textAyranQ.Text != "0")
            {
                ListViewItem drink = new ListViewItem("Ayran");
                drink.SubItems.Add(textAyranQ.Text);
                int totalAmount = Convert.ToInt32(textAyranQ.Text) * 2;
                drink.SubItems.Add(totalAmount.ToString());
                listOrder.Items.Add(drink);
            }
            if (textBerkBeerQ.Text != "0")
            {
                ListViewItem drink = new ListViewItem("Ayran");
                drink.SubItems.Add(textBerkBeerQ.Text);
                int totalAmount = Convert.ToInt32(textBerkBeerQ.Text) * 8;
                drink.SubItems.Add(totalAmount.ToString());
                listOrder.Items.Add(drink);
            }
            if (textWineQ.Text != "0")
            {
                ListViewItem drink = new ListViewItem("Ayran");
                drink.SubItems.Add(textWineQ.Text);
                int totalAmount = Convert.ToInt32(textWineQ.Text) * 25;
                drink.SubItems.Add(totalAmount.ToString());
                listOrder.Items.Add(drink);
            }
            if (text7DaysQ.Text != "0")
            {
                ListViewItem drink = new ListViewItem("7Days");
                drink.SubItems.Add(text7DaysQ.Text);
                int totalAmount = Convert.ToInt32(text7DaysQ.Text) * 3;
                drink.SubItems.Add(totalAmount.ToString());
                listOrder.Items.Add(drink);
            }
            if (textWaterQ.Text != "0")
            {
                ListViewItem drink = new ListViewItem("Water");
                drink.SubItems.Add(textWaterQ.Text);
                int totalAmount = Convert.ToInt32(textWaterQ.Text) * 2;
                drink.SubItems.Add(totalAmount.ToString());
                listOrder.Items.Add(drink);
            }
        }
        public void validateDigitQuantity(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                e.Handled = true;
            textCokeQ.MaxLength = 2;
            textDietCokeQ.MaxLength = 2;
            textAyranQ.MaxLength = 2;
            textBerkBeerQ.MaxLength = 2;
            textWineQ.MaxLength = 2;
            text7DaysQ.MaxLength = 2;
            textWaterQ.MaxLength = 2;
        }
        public void validateLetterNameAndSurname(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && (e.KeyChar != ' '))
            {
                e.Handled = true;
            }
            textName.MaxLength = 30;
            textSurname.MaxLength = 30;
        }
        public void clearTabOrder()
        {
            //Clearing size,sauce and crust
            radioSizeSmall.Checked = true;
            radioSauceRanch.Checked = true;
            radioCrustClassic.Checked = true;
            //Clearing snacks
            checkFrenchF.Checked = checkOnionR.Checked = checkChickenW.Checked = checkBuffaloW.Checked = checkCheesyS.Checked = checkTurkishB.Checked = false;
            //Clearing toppings
            checkMozzarella.Checked = checkJalepeno.Checked = checkSpinach.Checked = checkOnion.Checked = checkAnchovies.Checked = checkBacon.Checked = checkBeef.Checked = checkChicken.Checked = checkShrimp.Checked = checkPepper.Checked = checkPineApple.Checked = checkBelPaese.Checked = checkPepperoni.Checked = checkGorgonzola.Checked = checkOlive.Checked = checkMushroom.Checked = checkAsiago.Checked = checkTuna.Checked = false;
            //Clearing drinks
            textCokeQ.Text = textDietCokeQ.Text = textAyranQ.Text = textBerkBeerQ.Text = textWineQ.Text = text7DaysQ.Text = textWaterQ.Text = "0";

        }
       
        public void sendDataToCourier()
        {
            ListViewItem customerInfo = new ListViewItem(textName.Text);
            customerInfo.SubItems.Add(textSurname.Text);
            customerInfo.SubItems.Add(textAddress.Text);
            customerInfo.SubItems.Add(textPostCode.Text);
            customerInfo.SubItems.Add(comboPaymentMethod.SelectedItem.ToString());
            Form2._instance2.listCourier.Items.Add(customerInfo);


        }
        public void sendDataToChef()
        {
            StreamWriter sw = new StreamWriter("receipt.txt");

            foreach (var item in listOrder.Items)
            {
                sw.WriteLine(item.ToString());
            }

            sw.Close();

            StreamReader sr = new StreamReader("receipt.txt");
            while (!sr.EndOfStream)
            {
                Form2._instance2.listChef.Items.Add(sr.ReadLine());
            }
            sr.Close();
        }

        public void finalDiaglog()
        {
            DialogResult d = MessageBox.Show("Thank for choosing Berk's Delicious Pizza.Your pizza will be ready in 15 minutes and delivered as soon as possible.Do you want to exit?", "Exit!", MessageBoxButtons.YesNo);
            if (d == DialogResult.Yes)
            {
                File.WriteAllText("receipt.txt",String.Empty);
                this.Close();
            }
            else if (d == DialogResult.No)
            {
                clearTabOrder();
                listOrder.Items.Clear();
                textTotalAmount.Text = textTotalAmount2.Text = "";
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            //Identifying pizza size sauce and crust

            
            //form2.ChooseDynamicSauce();
            //form2.ChooseDynamicCrust();
            ChooseSize();
            form2.ChooseDynamicSize();
            ChooseSauce();
            form2.ChooseDynamicSauce();
            ChooseCrust();
            form2.ChooseDynamicCrust();
            ChooseToppings();
            ChooseSnack();
            form2.ChooseDynamicSnack();
            ChooseDrinks();
            
            //Calculating total order amount
            foreach (ListViewItem item in listOrder.Items)
            {
                totalAmount += Convert.ToInt32(item.SubItems[2].Text);
            }
            textTotalAmount.Text = totalAmount.ToString("c2");
            textTotalAmount2.Text = totalAmount.ToString("c2");

            tabControl1.SelectTab("tabConfirm");
        }

        //Text coke arrangement
        private void textCokeQ_Enter(object sender, EventArgs e)
        {
            if (textCokeQ.Text == "0")
                textCokeQ.Text = "";
        }

        private void textCokeQ_Leave(object sender, EventArgs e)
        {
            if (textCokeQ.Text.Trim() == "")
                textCokeQ.Text = "0";
        }

        private void textCokeQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            validateDigitQuantity(sender, e);
        }
        //Text diet coke arrangement
        private void textDietCokeQ_Enter(object sender, EventArgs e)
        {
            if (textDietCokeQ.Text == "0")
                textDietCokeQ.Text = "";
        }

        private void textDietCokeQ_Leave(object sender, EventArgs e)
        {
            if (textDietCokeQ.Text.Trim() == "")
                textDietCokeQ.Text = "0";


        }

        private void textDietCokeQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            validateDigitQuantity(sender, e);
        }
        //Text ayran arrangement
        private void textAyranQ_Enter(object sender, EventArgs e)
        {
            if (textAyranQ.Text == "0")
                textAyranQ.Text = "";
        }

        private void textAyranQ_Leave(object sender, EventArgs e)
        {
            if (textAyranQ.Text.Trim() == "")
                textAyranQ.Text = "0";
        }

        private void textAyranQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            validateDigitQuantity(sender, e);
        }
        //Text Berk's Beer arrangement
        private void textBerkBeerQ_Enter(object sender, EventArgs e)
        {
            if (textBerkBeerQ.Text == "0")
                textBerkBeerQ.Text = "";
        }

        private void textBerkBeerQ_Leave(object sender, EventArgs e)
        {
            if (textBerkBeerQ.Text.Trim() == "")
                textBerkBeerQ.Text = "0";
        }

        private void textBerkBeerQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            validateDigitQuantity(sender, e);
        }
        //Text wine arrangement
        private void textWineQ_Enter(object sender, EventArgs e)
        {
            if (textWineQ.Text == "0")
                textWineQ.Text = "";
        }

        private void textWineQ_Leave(object sender, EventArgs e)
        {
            if (textWineQ.Text.Trim() == "")
                textWineQ.Text = "0";
        }

        private void textWineQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            validateDigitQuantity(sender, e);
        }
        //Text 7days arrangement
        private void text7DaysQ_Enter(object sender, EventArgs e)
        {
            if (text7DaysQ.Text == "0")
                text7DaysQ.Text = "";
        }

        private void text7DaysQ_Leave(object sender, EventArgs e)
        {
            if (text7DaysQ.Text.Trim() == "")
                text7DaysQ.Text = "0";
        }

        private void text7DaysQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            validateDigitQuantity(sender, e);
        }
        //Text water arrangement
        private void textWaterQ_Enter(object sender, EventArgs e)
        {
            if (textWaterQ.Text == "0")
                textWaterQ.Text = "";
        }

        private void textWaterQ_Leave(object sender, EventArgs e)
        {
            if (textWaterQ.Text.Trim() == "")
                textWaterQ.Text = "0";
        }

        private void textWaterQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            validateDigitQuantity(sender, e);
        }

        private void btnPayAndEat_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab("tabPayment");
        }
        //Text Name arrangement
        private void textName_Enter(object sender, EventArgs e)
        {
            if (textName.Text == "Enter Your Name")
                textName.Text = "";
        }

        private void textName_Leave(object sender, EventArgs e)
        {
            if (textName.Text.Trim() == "")
                textName.Text = "Enter Your Name";
        }

        private void textName_KeyPress(object sender, KeyPressEventArgs e)
        {
            validateLetterNameAndSurname(sender, e);
        }
        //Text Surname arrangement
        private void textSurname_Enter(object sender, EventArgs e)
        {
            if (textSurname.Text == "Enter Your Surname")
                textSurname.Text = "";
        }

        private void textSurname_Leave(object sender, EventArgs e)
        {
            if (textSurname.Text.Trim() == "")
                textSurname.Text = "Enter Your Surname";
        }

        private void textSurname_KeyPress(object sender, KeyPressEventArgs e)
        {
            validateLetterNameAndSurname(sender, e);
        }
        //Text Address arrangement
        private void textAddress_Enter(object sender, EventArgs e)
        {
            if (textAddress.Text == "Enter Your Address")
                textAddress.Text = "";
        }

        private void textAddress_Leave(object sender, EventArgs e)
        {
            if (textAddress.Text.Trim() == "")
                textAddress.Text = "Enter Your Address";
        }
        //Text phone arrangement
        private void textPhone_Enter(object sender, EventArgs e)
        {
            if (textPhone.Text == "Enter Your Phone Number")
                textPhone.Text = "";
        }

        private void textPhone_Leave(object sender, EventArgs e)
        {
            if (textPhone.Text.Trim() == "")
                textPhone.Text = "Enter Your Phone Number";
            if (textPhone.Text.Length < 11)
                MessageBox.Show("You must enter 11 digits and patern must start with 0");
        }

        private void textPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Regex regEx = new Regex(@"\(?\d{3}\)?-? *\d{3}-? *-?\d{4}");
            textPhone.MaxLength = 11;
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;



        }
        //Text Post Code arrangement
        private void textPostCode_Enter(object sender, EventArgs e)
        {
            if (textPostCode.Text == "Enter Your Post Code")
                textPostCode.Text = "";
        }

        private void textPostCode_Leave(object sender, EventArgs e)
        {
            if (textPostCode.Text.Trim() == "")
                textPostCode.Text = "Enter Your Post Code";
            if (textPostCode.Text.Length < 5)
                MessageBox.Show("You must enter 5 digits!");
        }

        private void textPostCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            textPostCode.MaxLength = 5;
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }
        //Text Street arrangement
        private void textStreet_Enter(object sender, EventArgs e)
        {
            if (textStreet.Text == "Enter Your Street")
                textStreet.Text = "";
        }

        private void textStreet_Leave(object sender, EventArgs e)
        {
            if (textStreet.Text.Trim() == "")
                textStreet.Text = "Enter Your Street";
        }
        //Text Card Owner arrangement
        private void textCardOwner_Enter(object sender, EventArgs e)
        {
            if (textCardOwner.Text == "Enter Card's Owner Full Name")
                textCardOwner.Text = "";
        }

        private void textCardOwner_Leave(object sender, EventArgs e)
        {
            if (textCardOwner.Text.Trim() == "")
                textCardOwner.Text = "Enter Card's Owner Full Name";
        }

        private void textCardOwner_KeyPress(object sender, KeyPressEventArgs e)
        {
            validateLetterNameAndSurname(sender, e);
        }
        //Text Card Number arrangement
        private void textCardNo_Enter(object sender, EventArgs e)
        {
            if (textCardNo.Text == "Enter Card Number")
                textCardNo.Text = "";
            

        }

        private void textCardNo_Leave(object sender, EventArgs e)
        {
            if (textCardNo.Text.Trim() == "")
                textCardNo.Text = "Enter Card Number";
            if (textCardNo.Text.Length < 16)
                MessageBox.Show("You must enter 16 digits");
        }

        private void textCardNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            textCardNo.MaxLength = 16;
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
            Regex regexVisa = new Regex(@"^4[0-9]{12}(?:[0-9]{3})?$");
            Regex regexMasterCard = new Regex(@"^5[1-5][0-9]{14}$");
            if (regexVisa.IsMatch(textCardNo.Text))
                pictureBox1.Visible = true;
            else if (regexMasterCard.IsMatch(textCardNo.Text))
                pictureBox2.Visible = true;
            else
            {
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
            }
                



            //else
            //    pictureBox1.Visible = false;
        }

        //Text cvc arrangement
        private void textCvc_Enter(object sender, EventArgs e)
        {
            if (textCvc.Text == "Enter Cvc")
                textCvc.Text = "";
        }

        private void textCvc_Leave(object sender, EventArgs e)
        {
            if (textCvc.Text.Trim() == "")
                textCvc.Text = "Enter Cvc";
            if (textCvc.Text.Length < 3)
                MessageBox.Show("You must enter 3 digits");
        }

        private void textCvc_KeyPress(object sender, KeyPressEventArgs e)
        {
            textCardNo.MaxLength = 3;
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void btnGoBack2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab("tabConfirm");
        }


        private void BtnClear_Click(object sender, EventArgs e)
        {
            clearTabOrder();
        }

        private void BtnClear2_Click(object sender, EventArgs e)
        {
            listOrder.Items.Clear();
            textTotalAmount.Text = textTotalAmount2.Text = "";
        }

        private void BtnPayNOrder_Click(object sender, EventArgs e)
        {
            if(comboPaymentMethod.SelectedIndex == 0)
            {
                if (textName.Text == "Enter Your Name" || textSurname.Text == "Enter Your Surname" || textAddress.Text == "Enter Your Address" || textPhone.Text == "Enter Your Phone Number" || textPostCode.Text == "Enter Your Post Code")
                    MessageBox.Show("Please fill whole mandatory fields");
                else
                {
                    sendDataToChef();
                    finalDiaglog();
                    sendDataToCourier();
                }
                    
                   
            }
            else if (comboPaymentMethod.SelectedIndex == 1 || comboPaymentMethod.SelectedIndex == 2)
            {
                if (textName.Text == "Enter Your Name" || textSurname.Text == "Enter Your Surname" || textAddress.Text == "Enter Your Address" || textPhone.Text == "Enter Your Phone Number" || textPostCode.Text == "Enter Your Post Code" || comboPaymentMethod.SelectedIndex == -1 || textCardOwner.Text == "Enter Card's Owner Full Name" || textCardNo.Text == "Enter Card Number" || textCvc.Text == "Enter Cvc")
                    MessageBox.Show("Please fill whole mandatory fields");
                else
                {
                    sendDataToChef();
                    sendDataToCourier();
                    finalDiaglog();
                    
                }
                    
                   
            }
            
            
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            File.WriteAllText("receipt.txt", String.Empty);
        }
    }
}
