﻿namespace PizzaOrderingSystem
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.listChef = new System.Windows.Forms.ListView();
            this.columnItem = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.listCourier = new System.Windows.Forms.ListView();
            this.columnName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnSurname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnAddress = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnPostCode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panelAddNewSnacks = new System.Windows.Forms.Panel();
            this.txtSnackCost = new System.Windows.Forms.TextBox();
            this.btnAddNewSnack = new System.Windows.Forms.Button();
            this.txtSnackName = new System.Windows.Forms.TextBox();
            this.labelSnackCost = new System.Windows.Forms.Label();
            this.labelSnackName = new System.Windows.Forms.Label();
            this.labelNewSnacks = new System.Windows.Forms.Label();
            this.panelAddNewCrust = new System.Windows.Forms.Panel();
            this.txtCrustCost = new System.Windows.Forms.TextBox();
            this.btnAddNewCrust = new System.Windows.Forms.Button();
            this.txtCrustName = new System.Windows.Forms.TextBox();
            this.lblCrustCost = new System.Windows.Forms.Label();
            this.lblCrustName = new System.Windows.Forms.Label();
            this.lblNewCrust = new System.Windows.Forms.Label();
            this.panelAddNewSauce = new System.Windows.Forms.Panel();
            this.txtSauceCost = new System.Windows.Forms.TextBox();
            this.btnAddNewSauce = new System.Windows.Forms.Button();
            this.txtSauceName = new System.Windows.Forms.TextBox();
            this.lblSauceCost = new System.Windows.Forms.Label();
            this.lblSauceName = new System.Windows.Forms.Label();
            this.lblNewSauce = new System.Windows.Forms.Label();
            this.panelAddNewSize = new System.Windows.Forms.Panel();
            this.txtSizeCost = new System.Windows.Forms.TextBox();
            this.btnAddNewSize = new System.Windows.Forms.Button();
            this.txtSizeName = new System.Windows.Forms.TextBox();
            this.lblSizeCost = new System.Windows.Forms.Label();
            this.lblSizeName = new System.Windows.Forms.Label();
            this.lblNewSize = new System.Windows.Forms.Label();
            this.columnPayment = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panelAddNewSnacks.SuspendLayout();
            this.panelAddNewCrust.SuspendLayout();
            this.panelAddNewSauce.SuspendLayout();
            this.panelAddNewSize.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabControl1.Location = new System.Drawing.Point(40, 46);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1002, 679);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Tomato;
            this.tabPage1.Controls.Add(this.listChef);
            this.tabPage1.Location = new System.Drawing.Point(4, 38);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(994, 637);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Chef Page";
            // 
            // listChef
            // 
            this.listChef.BackColor = System.Drawing.Color.SandyBrown;
            this.listChef.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnItem});
            this.listChef.FullRowSelect = true;
            this.listChef.Location = new System.Drawing.Point(19, 40);
            this.listChef.Name = "listChef";
            this.listChef.Size = new System.Drawing.Size(957, 597);
            this.listChef.TabIndex = 0;
            this.listChef.UseCompatibleStateImageBehavior = false;
            this.listChef.View = System.Windows.Forms.View.Details;
            // 
            // columnItem
            // 
            this.columnItem.Text = "Selected Item";
            this.columnItem.Width = 307;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Tomato;
            this.tabPage2.Controls.Add(this.listCourier);
            this.tabPage2.Location = new System.Drawing.Point(4, 38);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(994, 637);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Courier Page";
            // 
            // listCourier
            // 
            this.listCourier.BackColor = System.Drawing.Color.SandyBrown;
            this.listCourier.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnName,
            this.columnSurname,
            this.columnAddress,
            this.columnPostCode,
            this.columnPayment});
            this.listCourier.FullRowSelect = true;
            this.listCourier.Location = new System.Drawing.Point(24, 33);
            this.listCourier.Name = "listCourier";
            this.listCourier.Size = new System.Drawing.Size(944, 598);
            this.listCourier.TabIndex = 0;
            this.listCourier.UseCompatibleStateImageBehavior = false;
            this.listCourier.View = System.Windows.Forms.View.Details;
            // 
            // columnName
            // 
            this.columnName.Text = "Name";
            this.columnName.Width = 145;
            // 
            // columnSurname
            // 
            this.columnSurname.Text = "Surname";
            this.columnSurname.Width = 175;
            // 
            // columnAddress
            // 
            this.columnAddress.Text = "Address";
            this.columnAddress.Width = 270;
            // 
            // columnPostCode
            // 
            this.columnPostCode.Text = "Post Code";
            this.columnPostCode.Width = 178;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Tomato;
            this.tabPage3.Controls.Add(this.panelAddNewSnacks);
            this.tabPage3.Controls.Add(this.panelAddNewCrust);
            this.tabPage3.Controls.Add(this.panelAddNewSauce);
            this.tabPage3.Controls.Add(this.panelAddNewSize);
            this.tabPage3.Location = new System.Drawing.Point(4, 38);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(994, 637);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Add New Items";
            // 
            // panelAddNewSnacks
            // 
            this.panelAddNewSnacks.BackColor = System.Drawing.Color.SandyBrown;
            this.panelAddNewSnacks.Controls.Add(this.txtSnackCost);
            this.panelAddNewSnacks.Controls.Add(this.btnAddNewSnack);
            this.panelAddNewSnacks.Controls.Add(this.txtSnackName);
            this.panelAddNewSnacks.Controls.Add(this.labelSnackCost);
            this.panelAddNewSnacks.Controls.Add(this.labelSnackName);
            this.panelAddNewSnacks.Controls.Add(this.labelNewSnacks);
            this.panelAddNewSnacks.Location = new System.Drawing.Point(389, 264);
            this.panelAddNewSnacks.Name = "panelAddNewSnacks";
            this.panelAddNewSnacks.Size = new System.Drawing.Size(341, 211);
            this.panelAddNewSnacks.TabIndex = 8;
            // 
            // txtSnackCost
            // 
            this.txtSnackCost.Location = new System.Drawing.Point(175, 107);
            this.txtSnackCost.Name = "txtSnackCost";
            this.txtSnackCost.Size = new System.Drawing.Size(143, 36);
            this.txtSnackCost.TabIndex = 4;
            // 
            // btnAddNewSnack
            // 
            this.btnAddNewSnack.Location = new System.Drawing.Point(172, 149);
            this.btnAddNewSnack.Name = "btnAddNewSnack";
            this.btnAddNewSnack.Size = new System.Drawing.Size(146, 37);
            this.btnAddNewSnack.TabIndex = 6;
            this.btnAddNewSnack.Text = "ADD";
            this.btnAddNewSnack.UseVisualStyleBackColor = true;
            this.btnAddNewSnack.Click += new System.EventHandler(this.BtnAddNewSnack_Click);
            // 
            // txtSnackName
            // 
            this.txtSnackName.Location = new System.Drawing.Point(175, 64);
            this.txtSnackName.Name = "txtSnackName";
            this.txtSnackName.Size = new System.Drawing.Size(143, 36);
            this.txtSnackName.TabIndex = 3;
            // 
            // labelSnackCost
            // 
            this.labelSnackCost.AutoSize = true;
            this.labelSnackCost.Location = new System.Drawing.Point(3, 110);
            this.labelSnackCost.Name = "labelSnackCost";
            this.labelSnackCost.Size = new System.Drawing.Size(161, 29);
            this.labelSnackCost.TabIndex = 2;
            this.labelSnackCost.Text = "Snack Cost:";
            // 
            // labelSnackName
            // 
            this.labelSnackName.AutoSize = true;
            this.labelSnackName.Location = new System.Drawing.Point(3, 67);
            this.labelSnackName.Name = "labelSnackName";
            this.labelSnackName.Size = new System.Drawing.Size(177, 29);
            this.labelSnackName.TabIndex = 1;
            this.labelSnackName.Text = "Snack Name:";
            // 
            // labelNewSnacks
            // 
            this.labelNewSnacks.AutoSize = true;
            this.labelNewSnacks.Location = new System.Drawing.Point(75, 16);
            this.labelNewSnacks.Name = "labelNewSnacks";
            this.labelNewSnacks.Size = new System.Drawing.Size(206, 29);
            this.labelNewSnacks.TabIndex = 0;
            this.labelNewSnacks.Text = "Add New Snack";
            // 
            // panelAddNewCrust
            // 
            this.panelAddNewCrust.BackColor = System.Drawing.Color.SandyBrown;
            this.panelAddNewCrust.Controls.Add(this.txtCrustCost);
            this.panelAddNewCrust.Controls.Add(this.btnAddNewCrust);
            this.panelAddNewCrust.Controls.Add(this.txtCrustName);
            this.panelAddNewCrust.Controls.Add(this.lblCrustCost);
            this.panelAddNewCrust.Controls.Add(this.lblCrustName);
            this.panelAddNewCrust.Controls.Add(this.lblNewCrust);
            this.panelAddNewCrust.Location = new System.Drawing.Point(28, 264);
            this.panelAddNewCrust.Name = "panelAddNewCrust";
            this.panelAddNewCrust.Size = new System.Drawing.Size(341, 211);
            this.panelAddNewCrust.TabIndex = 7;
            // 
            // txtCrustCost
            // 
            this.txtCrustCost.Location = new System.Drawing.Point(175, 107);
            this.txtCrustCost.Name = "txtCrustCost";
            this.txtCrustCost.Size = new System.Drawing.Size(143, 36);
            this.txtCrustCost.TabIndex = 4;
            // 
            // btnAddNewCrust
            // 
            this.btnAddNewCrust.Location = new System.Drawing.Point(172, 149);
            this.btnAddNewCrust.Name = "btnAddNewCrust";
            this.btnAddNewCrust.Size = new System.Drawing.Size(146, 37);
            this.btnAddNewCrust.TabIndex = 6;
            this.btnAddNewCrust.Text = "ADD";
            this.btnAddNewCrust.UseVisualStyleBackColor = true;
            this.btnAddNewCrust.Click += new System.EventHandler(this.BtnAddNewCrust_Click);
            // 
            // txtCrustName
            // 
            this.txtCrustName.Location = new System.Drawing.Point(175, 64);
            this.txtCrustName.Name = "txtCrustName";
            this.txtCrustName.Size = new System.Drawing.Size(143, 36);
            this.txtCrustName.TabIndex = 3;
            // 
            // lblCrustCost
            // 
            this.lblCrustCost.AutoSize = true;
            this.lblCrustCost.Location = new System.Drawing.Point(3, 110);
            this.lblCrustCost.Name = "lblCrustCost";
            this.lblCrustCost.Size = new System.Drawing.Size(150, 29);
            this.lblCrustCost.TabIndex = 2;
            this.lblCrustCost.Text = "Crust Cost:";
            // 
            // lblCrustName
            // 
            this.lblCrustName.AutoSize = true;
            this.lblCrustName.Location = new System.Drawing.Point(3, 67);
            this.lblCrustName.Name = "lblCrustName";
            this.lblCrustName.Size = new System.Drawing.Size(166, 29);
            this.lblCrustName.TabIndex = 1;
            this.lblCrustName.Text = "Crust Name:";
            // 
            // lblNewCrust
            // 
            this.lblNewCrust.AutoSize = true;
            this.lblNewCrust.Location = new System.Drawing.Point(75, 16);
            this.lblNewCrust.Name = "lblNewCrust";
            this.lblNewCrust.Size = new System.Drawing.Size(195, 29);
            this.lblNewCrust.TabIndex = 0;
            this.lblNewCrust.Text = "Add New Crust";
            // 
            // panelAddNewSauce
            // 
            this.panelAddNewSauce.BackColor = System.Drawing.Color.SandyBrown;
            this.panelAddNewSauce.Controls.Add(this.txtSauceCost);
            this.panelAddNewSauce.Controls.Add(this.btnAddNewSauce);
            this.panelAddNewSauce.Controls.Add(this.txtSauceName);
            this.panelAddNewSauce.Controls.Add(this.lblSauceCost);
            this.panelAddNewSauce.Controls.Add(this.lblSauceName);
            this.panelAddNewSauce.Controls.Add(this.lblNewSauce);
            this.panelAddNewSauce.Location = new System.Drawing.Point(389, 26);
            this.panelAddNewSauce.Name = "panelAddNewSauce";
            this.panelAddNewSauce.Size = new System.Drawing.Size(375, 215);
            this.panelAddNewSauce.TabIndex = 5;
            // 
            // txtSauceCost
            // 
            this.txtSauceCost.Location = new System.Drawing.Point(197, 114);
            this.txtSauceCost.Name = "txtSauceCost";
            this.txtSauceCost.Size = new System.Drawing.Size(143, 36);
            this.txtSauceCost.TabIndex = 4;
            // 
            // btnAddNewSauce
            // 
            this.btnAddNewSauce.Location = new System.Drawing.Point(197, 163);
            this.btnAddNewSauce.Name = "btnAddNewSauce";
            this.btnAddNewSauce.Size = new System.Drawing.Size(146, 38);
            this.btnAddNewSauce.TabIndex = 0;
            this.btnAddNewSauce.Text = "ADD NEW SIZE";
            this.btnAddNewSauce.UseVisualStyleBackColor = true;
            this.btnAddNewSauce.Click += new System.EventHandler(this.BtnAddNewSauce_Click);
            // 
            // txtSauceName
            // 
            this.txtSauceName.Location = new System.Drawing.Point(197, 60);
            this.txtSauceName.Name = "txtSauceName";
            this.txtSauceName.Size = new System.Drawing.Size(143, 36);
            this.txtSauceName.TabIndex = 3;
            // 
            // lblSauceCost
            // 
            this.lblSauceCost.AutoSize = true;
            this.lblSauceCost.Location = new System.Drawing.Point(19, 117);
            this.lblSauceCost.Name = "lblSauceCost";
            this.lblSauceCost.Size = new System.Drawing.Size(162, 29);
            this.lblSauceCost.TabIndex = 2;
            this.lblSauceCost.Text = "Sauce Cost:";
            // 
            // lblSauceName
            // 
            this.lblSauceName.AutoSize = true;
            this.lblSauceName.Location = new System.Drawing.Point(13, 67);
            this.lblSauceName.Name = "lblSauceName";
            this.lblSauceName.Size = new System.Drawing.Size(178, 29);
            this.lblSauceName.TabIndex = 1;
            this.lblSauceName.Text = "Sauce Name:";
            // 
            // lblNewSauce
            // 
            this.lblNewSauce.AutoSize = true;
            this.lblNewSauce.Location = new System.Drawing.Point(75, 15);
            this.lblNewSauce.Name = "lblNewSauce";
            this.lblNewSauce.Size = new System.Drawing.Size(207, 29);
            this.lblNewSauce.TabIndex = 0;
            this.lblNewSauce.Text = "Add New Sauce";
            // 
            // panelAddNewSize
            // 
            this.panelAddNewSize.BackColor = System.Drawing.Color.SandyBrown;
            this.panelAddNewSize.Controls.Add(this.txtSizeCost);
            this.panelAddNewSize.Controls.Add(this.btnAddNewSize);
            this.panelAddNewSize.Controls.Add(this.txtSizeName);
            this.panelAddNewSize.Controls.Add(this.lblSizeCost);
            this.panelAddNewSize.Controls.Add(this.lblSizeName);
            this.panelAddNewSize.Controls.Add(this.lblNewSize);
            this.panelAddNewSize.Location = new System.Drawing.Point(28, 26);
            this.panelAddNewSize.Name = "panelAddNewSize";
            this.panelAddNewSize.Size = new System.Drawing.Size(341, 215);
            this.panelAddNewSize.TabIndex = 1;
            // 
            // txtSizeCost
            // 
            this.txtSizeCost.Location = new System.Drawing.Point(175, 110);
            this.txtSizeCost.Name = "txtSizeCost";
            this.txtSizeCost.Size = new System.Drawing.Size(143, 36);
            this.txtSizeCost.TabIndex = 4;
            // 
            // btnAddNewSize
            // 
            this.btnAddNewSize.Location = new System.Drawing.Point(172, 163);
            this.btnAddNewSize.Name = "btnAddNewSize";
            this.btnAddNewSize.Size = new System.Drawing.Size(146, 38);
            this.btnAddNewSize.TabIndex = 0;
            this.btnAddNewSize.Text = "ADD NEW SIZE";
            this.btnAddNewSize.UseVisualStyleBackColor = true;
            this.btnAddNewSize.Click += new System.EventHandler(this.btnAddNewSize_Click);
            // 
            // txtSizeName
            // 
            this.txtSizeName.Location = new System.Drawing.Point(175, 60);
            this.txtSizeName.Name = "txtSizeName";
            this.txtSizeName.Size = new System.Drawing.Size(143, 36);
            this.txtSizeName.TabIndex = 3;
            // 
            // lblSizeCost
            // 
            this.lblSizeCost.AutoSize = true;
            this.lblSizeCost.Location = new System.Drawing.Point(19, 117);
            this.lblSizeCost.Name = "lblSizeCost";
            this.lblSizeCost.Size = new System.Drawing.Size(139, 29);
            this.lblSizeCost.TabIndex = 2;
            this.lblSizeCost.Text = "Size Cost:";
            // 
            // lblSizeName
            // 
            this.lblSizeName.AutoSize = true;
            this.lblSizeName.Location = new System.Drawing.Point(14, 67);
            this.lblSizeName.Name = "lblSizeName";
            this.lblSizeName.Size = new System.Drawing.Size(155, 29);
            this.lblSizeName.TabIndex = 1;
            this.lblSizeName.Text = "Size Name:";
            // 
            // lblNewSize
            // 
            this.lblNewSize.AutoSize = true;
            this.lblNewSize.Location = new System.Drawing.Point(75, 15);
            this.lblNewSize.Name = "lblNewSize";
            this.lblNewSize.Size = new System.Drawing.Size(184, 29);
            this.lblNewSize.TabIndex = 0;
            this.lblNewSize.Text = "Add New Size";
            // 
            // columnPayment
            // 
            this.columnPayment.Text = "Payment";
            this.columnPayment.Width = 144;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Sienna;
            this.ClientSize = new System.Drawing.Size(1086, 737);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form2";
            this.Text = "Employee Page";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.panelAddNewSnacks.ResumeLayout(false);
            this.panelAddNewSnacks.PerformLayout();
            this.panelAddNewCrust.ResumeLayout(false);
            this.panelAddNewCrust.PerformLayout();
            this.panelAddNewSauce.ResumeLayout(false);
            this.panelAddNewSauce.PerformLayout();
            this.panelAddNewSize.ResumeLayout(false);
            this.panelAddNewSize.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        public System.Windows.Forms.ListView listChef;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ColumnHeader columnItem;
        public System.Windows.Forms.ListView listCourier;
        private System.Windows.Forms.ColumnHeader columnName;
        private System.Windows.Forms.ColumnHeader columnSurname;
        private System.Windows.Forms.ColumnHeader columnAddress;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnAddNewSize;
        private System.Windows.Forms.Panel panelAddNewSize;
        private System.Windows.Forms.TextBox txtSizeCost;
        private System.Windows.Forms.TextBox txtSizeName;
        private System.Windows.Forms.Label lblSizeCost;
        private System.Windows.Forms.Label lblSizeName;
        private System.Windows.Forms.Label lblNewSize;
        private System.Windows.Forms.Panel panelAddNewSauce;
        private System.Windows.Forms.TextBox txtSauceCost;
        private System.Windows.Forms.Button btnAddNewSauce;
        private System.Windows.Forms.TextBox txtSauceName;
        private System.Windows.Forms.Label lblSauceCost;
        private System.Windows.Forms.Label lblSauceName;
        private System.Windows.Forms.Label lblNewSauce;
        private System.Windows.Forms.Button btnAddNewCrust;
        private System.Windows.Forms.Panel panelAddNewCrust;
        private System.Windows.Forms.TextBox txtCrustCost;
        private System.Windows.Forms.TextBox txtCrustName;
        private System.Windows.Forms.Label lblCrustCost;
        private System.Windows.Forms.Label lblCrustName;
        private System.Windows.Forms.Label lblNewCrust;
        private System.Windows.Forms.Panel panelAddNewSnacks;
        private System.Windows.Forms.TextBox txtSnackCost;
        private System.Windows.Forms.Button btnAddNewSnack;
        private System.Windows.Forms.TextBox txtSnackName;
        private System.Windows.Forms.Label labelSnackCost;
        private System.Windows.Forms.Label labelSnackName;
        private System.Windows.Forms.Label labelNewSnacks;
        private System.Windows.Forms.ColumnHeader columnPostCode;
        private System.Windows.Forms.ColumnHeader columnPayment;
    }
}