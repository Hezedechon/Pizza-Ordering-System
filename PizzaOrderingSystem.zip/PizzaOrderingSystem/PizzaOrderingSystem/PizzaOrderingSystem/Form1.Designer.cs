﻿namespace PizzaOrderingSystem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabOrder = new System.Windows.Forms.TabPage();
            this.panelToppings = new System.Windows.Forms.Panel();
            this.labelToppings = new System.Windows.Forms.Label();
            this.checkMushroom = new System.Windows.Forms.CheckBox();
            this.checkPepperoni = new System.Windows.Forms.CheckBox();
            this.checkTuna = new System.Windows.Forms.CheckBox();
            this.checkJalepeno = new System.Windows.Forms.CheckBox();
            this.checkPepper = new System.Windows.Forms.CheckBox();
            this.checkOlive = new System.Windows.Forms.CheckBox();
            this.checkAnchovies = new System.Windows.Forms.CheckBox();
            this.checkBeef = new System.Windows.Forms.CheckBox();
            this.checkBelPaese = new System.Windows.Forms.CheckBox();
            this.checkChicken = new System.Windows.Forms.CheckBox();
            this.checkOnion = new System.Windows.Forms.CheckBox();
            this.checkShrimp = new System.Windows.Forms.CheckBox();
            this.checkPineApple = new System.Windows.Forms.CheckBox();
            this.checkMozzarella = new System.Windows.Forms.CheckBox();
            this.checkBacon = new System.Windows.Forms.CheckBox();
            this.checkGorgonzola = new System.Windows.Forms.CheckBox();
            this.checkAsiago = new System.Windows.Forms.CheckBox();
            this.checkSpinach = new System.Windows.Forms.CheckBox();
            this.panelSnacks = new System.Windows.Forms.Panel();
            this.lblSnacks = new System.Windows.Forms.Label();
            this.checkFrenchF = new System.Windows.Forms.CheckBox();
            this.checkTurkishB = new System.Windows.Forms.CheckBox();
            this.checkOnionR = new System.Windows.Forms.CheckBox();
            this.checkChickenW = new System.Windows.Forms.CheckBox();
            this.checkCheesyS = new System.Windows.Forms.CheckBox();
            this.checkBuffaloW = new System.Windows.Forms.CheckBox();
            this.panelCrust = new System.Windows.Forms.Panel();
            this.lblCrust = new System.Windows.Forms.Label();
            this.radioCrustSquare = new System.Windows.Forms.RadioButton();
            this.radioCrustClassic = new System.Windows.Forms.RadioButton();
            this.radioCrustDouble = new System.Windows.Forms.RadioButton();
            this.radioCrustSausage = new System.Windows.Forms.RadioButton();
            this.panelSauce = new System.Windows.Forms.Panel();
            this.lblSauce = new System.Windows.Forms.Label();
            this.radioSauceBerk = new System.Windows.Forms.RadioButton();
            this.radioSauceRanch = new System.Windows.Forms.RadioButton();
            this.radioSauceBarbeque = new System.Windows.Forms.RadioButton();
            this.radioSaucePesto = new System.Windows.Forms.RadioButton();
            this.panelSize = new System.Windows.Forms.Panel();
            this.lblSize = new System.Windows.Forms.Label();
            this.radioSizeLarge = new System.Windows.Forms.RadioButton();
            this.radioSizeKing = new System.Windows.Forms.RadioButton();
            this.radioSizeMedium = new System.Windows.Forms.RadioButton();
            this.radioSizeSmall = new System.Windows.Forms.RadioButton();
            this.groupDrinks = new System.Windows.Forms.GroupBox();
            this.textWaterQ = new System.Windows.Forms.TextBox();
            this.text7DaysQ = new System.Windows.Forms.TextBox();
            this.textWineQ = new System.Windows.Forms.TextBox();
            this.textBerkBeerQ = new System.Windows.Forms.TextBox();
            this.textAyranQ = new System.Windows.Forms.TextBox();
            this.textDietCokeQ = new System.Windows.Forms.TextBox();
            this.textCokeQ = new System.Windows.Forms.TextBox();
            this.labelWater = new System.Windows.Forms.Label();
            this.label7Days = new System.Windows.Forms.Label();
            this.labelWine = new System.Windows.Forms.Label();
            this.labelBerkBeer = new System.Windows.Forms.Label();
            this.labelAyran = new System.Windows.Forms.Label();
            this.labelDietCoke = new System.Windows.Forms.Label();
            this.labelCoke = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.tabConfirm = new System.Windows.Forms.TabPage();
            this.textTotalAmount = new System.Windows.Forms.TextBox();
            this.labelTotalAmount = new System.Windows.Forms.Label();
            this.btnPayAndEat = new System.Windows.Forms.Button();
            this.btnClear2 = new System.Windows.Forms.Button();
            this.btnGoBack = new System.Windows.Forms.Button();
            this.listOrder = new System.Windows.Forms.ListView();
            this.columnItems = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnQuantity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPayment = new System.Windows.Forms.TabPage();
            this.btnPayNOrder = new System.Windows.Forms.Button();
            this.btnGoBack2 = new System.Windows.Forms.Button();
            this.groupPaymentField = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBerkCoupon = new System.Windows.Forms.TextBox();
            this.textTotalAmount2 = new System.Windows.Forms.TextBox();
            this.textCvc = new System.Windows.Forms.TextBox();
            this.textCardNo = new System.Windows.Forms.TextBox();
            this.textCardOwner = new System.Windows.Forms.TextBox();
            this.comboPaymentMethod = new System.Windows.Forms.ComboBox();
            this.labelBerkCoupon = new System.Windows.Forms.Label();
            this.labelTotalAmount2 = new System.Windows.Forms.Label();
            this.labelCvc = new System.Windows.Forms.Label();
            this.labelCardNo = new System.Windows.Forms.Label();
            this.labelCardOwner = new System.Windows.Forms.Label();
            this.labelPaymentMethod = new System.Windows.Forms.Label();
            this.labelFieldMFilled = new System.Windows.Forms.Label();
            this.groupInfoFİeld = new System.Windows.Forms.GroupBox();
            this.textStreet = new System.Windows.Forms.TextBox();
            this.textPostCode = new System.Windows.Forms.TextBox();
            this.textPhone = new System.Windows.Forms.TextBox();
            this.textAddress = new System.Windows.Forms.TextBox();
            this.textSurname = new System.Windows.Forms.TextBox();
            this.textName = new System.Windows.Forms.TextBox();
            this.labelStreet = new System.Windows.Forms.Label();
            this.labelPostCode = new System.Windows.Forms.Label();
            this.labelPhone = new System.Windows.Forms.Label();
            this.labelAddress = new System.Windows.Forms.Label();
            this.labelSurname = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textPassword = new System.Windows.Forms.TextBox();
            this.textUserName = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabOrder.SuspendLayout();
            this.panelToppings.SuspendLayout();
            this.panelSnacks.SuspendLayout();
            this.panelCrust.SuspendLayout();
            this.panelSauce.SuspendLayout();
            this.panelSize.SuspendLayout();
            this.groupDrinks.SuspendLayout();
            this.tabConfirm.SuspendLayout();
            this.tabPayment.SuspendLayout();
            this.groupPaymentField.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupInfoFİeld.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabOrder);
            this.tabControl1.Controls.Add(this.tabConfirm);
            this.tabControl1.Controls.Add(this.tabPayment);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1091, 1164);
            this.tabControl1.TabIndex = 0;
            // 
            // tabOrder
            // 
            this.tabOrder.BackColor = System.Drawing.Color.Tomato;
            this.tabOrder.Controls.Add(this.panelToppings);
            this.tabOrder.Controls.Add(this.panelSnacks);
            this.tabOrder.Controls.Add(this.panelCrust);
            this.tabOrder.Controls.Add(this.panelSauce);
            this.tabOrder.Controls.Add(this.panelSize);
            this.tabOrder.Controls.Add(this.groupDrinks);
            this.tabOrder.Controls.Add(this.btnConfirm);
            this.tabOrder.Controls.Add(this.btnClear);
            this.tabOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabOrder.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tabOrder.Location = new System.Drawing.Point(4, 38);
            this.tabOrder.Name = "tabOrder";
            this.tabOrder.Padding = new System.Windows.Forms.Padding(3);
            this.tabOrder.Size = new System.Drawing.Size(1083, 1122);
            this.tabOrder.TabIndex = 0;
            this.tabOrder.Text = "Order Your Pizza!";
            // 
            // panelToppings
            // 
            this.panelToppings.BackColor = System.Drawing.Color.SandyBrown;
            this.panelToppings.Controls.Add(this.labelToppings);
            this.panelToppings.Controls.Add(this.checkMushroom);
            this.panelToppings.Controls.Add(this.checkPepperoni);
            this.panelToppings.Controls.Add(this.checkTuna);
            this.panelToppings.Controls.Add(this.checkJalepeno);
            this.panelToppings.Controls.Add(this.checkPepper);
            this.panelToppings.Controls.Add(this.checkOlive);
            this.panelToppings.Controls.Add(this.checkAnchovies);
            this.panelToppings.Controls.Add(this.checkBeef);
            this.panelToppings.Controls.Add(this.checkBelPaese);
            this.panelToppings.Controls.Add(this.checkChicken);
            this.panelToppings.Controls.Add(this.checkOnion);
            this.panelToppings.Controls.Add(this.checkShrimp);
            this.panelToppings.Controls.Add(this.checkPineApple);
            this.panelToppings.Controls.Add(this.checkMozzarella);
            this.panelToppings.Controls.Add(this.checkBacon);
            this.panelToppings.Controls.Add(this.checkGorgonzola);
            this.panelToppings.Controls.Add(this.checkAsiago);
            this.panelToppings.Controls.Add(this.checkSpinach);
            this.panelToppings.Location = new System.Drawing.Point(16, 359);
            this.panelToppings.Name = "panelToppings";
            this.panelToppings.Size = new System.Drawing.Size(554, 443);
            this.panelToppings.TabIndex = 19;
            // 
            // labelToppings
            // 
            this.labelToppings.AutoSize = true;
            this.labelToppings.ForeColor = System.Drawing.Color.Crimson;
            this.labelToppings.Location = new System.Drawing.Point(30, 382);
            this.labelToppings.Name = "labelToppings";
            this.labelToppings.Size = new System.Drawing.Size(183, 29);
            this.labelToppings.TabIndex = 18;
            this.labelToppings.Text = "Each Top 1TL";
            // 
            // checkMushroom
            // 
            this.checkMushroom.AutoSize = true;
            this.checkMushroom.Location = new System.Drawing.Point(30, 320);
            this.checkMushroom.Name = "checkMushroom";
            this.checkMushroom.Size = new System.Drawing.Size(163, 33);
            this.checkMushroom.TabIndex = 5;
            this.checkMushroom.Text = "Mushroom";
            this.checkMushroom.UseVisualStyleBackColor = true;
            // 
            // checkPepperoni
            // 
            this.checkPepperoni.AutoSize = true;
            this.checkPepperoni.Location = new System.Drawing.Point(30, 262);
            this.checkPepperoni.Name = "checkPepperoni";
            this.checkPepperoni.Size = new System.Drawing.Size(159, 33);
            this.checkPepperoni.TabIndex = 4;
            this.checkPepperoni.Text = "Pepperoni";
            this.checkPepperoni.UseVisualStyleBackColor = true;
            // 
            // checkTuna
            // 
            this.checkTuna.AutoSize = true;
            this.checkTuna.Location = new System.Drawing.Point(378, 320);
            this.checkTuna.Name = "checkTuna";
            this.checkTuna.Size = new System.Drawing.Size(96, 33);
            this.checkTuna.TabIndex = 17;
            this.checkTuna.Text = "Tuna";
            this.checkTuna.UseVisualStyleBackColor = true;
            // 
            // checkJalepeno
            // 
            this.checkJalepeno.AutoSize = true;
            this.checkJalepeno.Location = new System.Drawing.Point(204, 48);
            this.checkJalepeno.Name = "checkJalepeno";
            this.checkJalepeno.Size = new System.Drawing.Size(146, 33);
            this.checkJalepeno.TabIndex = 6;
            this.checkJalepeno.Text = "Jalepeno";
            this.checkJalepeno.UseVisualStyleBackColor = true;
            // 
            // checkPepper
            // 
            this.checkPepper.AutoSize = true;
            this.checkPepper.Location = new System.Drawing.Point(30, 209);
            this.checkPepper.Name = "checkPepper";
            this.checkPepper.Size = new System.Drawing.Size(122, 33);
            this.checkPepper.TabIndex = 3;
            this.checkPepper.Text = "Pepper";
            this.checkPepper.UseVisualStyleBackColor = true;
            // 
            // checkOlive
            // 
            this.checkOlive.AutoSize = true;
            this.checkOlive.Location = new System.Drawing.Point(378, 262);
            this.checkOlive.Name = "checkOlive";
            this.checkOlive.Size = new System.Drawing.Size(98, 33);
            this.checkOlive.TabIndex = 16;
            this.checkOlive.Text = "Olive";
            this.checkOlive.UseVisualStyleBackColor = true;
            // 
            // checkAnchovies
            // 
            this.checkAnchovies.AutoSize = true;
            this.checkAnchovies.Location = new System.Drawing.Point(204, 105);
            this.checkAnchovies.Name = "checkAnchovies";
            this.checkAnchovies.Size = new System.Drawing.Size(162, 33);
            this.checkAnchovies.TabIndex = 7;
            this.checkAnchovies.Text = "Anchovies";
            this.checkAnchovies.UseVisualStyleBackColor = true;
            // 
            // checkBeef
            // 
            this.checkBeef.AutoSize = true;
            this.checkBeef.Location = new System.Drawing.Point(30, 158);
            this.checkBeef.Name = "checkBeef";
            this.checkBeef.Size = new System.Drawing.Size(91, 33);
            this.checkBeef.TabIndex = 2;
            this.checkBeef.Text = "Beef";
            this.checkBeef.UseVisualStyleBackColor = true;
            // 
            // checkBelPaese
            // 
            this.checkBelPaese.AutoSize = true;
            this.checkBelPaese.Location = new System.Drawing.Point(378, 209);
            this.checkBelPaese.Name = "checkBelPaese";
            this.checkBelPaese.Size = new System.Drawing.Size(160, 33);
            this.checkBelPaese.TabIndex = 15;
            this.checkBelPaese.Text = "Bel Paese";
            this.checkBelPaese.UseVisualStyleBackColor = true;
            // 
            // checkChicken
            // 
            this.checkChicken.AutoSize = true;
            this.checkChicken.Location = new System.Drawing.Point(204, 158);
            this.checkChicken.Name = "checkChicken";
            this.checkChicken.Size = new System.Drawing.Size(134, 33);
            this.checkChicken.TabIndex = 8;
            this.checkChicken.Text = "Chicken";
            this.checkChicken.UseVisualStyleBackColor = true;
            // 
            // checkOnion
            // 
            this.checkOnion.AutoSize = true;
            this.checkOnion.Location = new System.Drawing.Point(30, 105);
            this.checkOnion.Name = "checkOnion";
            this.checkOnion.Size = new System.Drawing.Size(107, 33);
            this.checkOnion.TabIndex = 1;
            this.checkOnion.Text = "Onion";
            this.checkOnion.UseVisualStyleBackColor = true;
            // 
            // checkShrimp
            // 
            this.checkShrimp.AutoSize = true;
            this.checkShrimp.Location = new System.Drawing.Point(378, 158);
            this.checkShrimp.Name = "checkShrimp";
            this.checkShrimp.Size = new System.Drawing.Size(122, 33);
            this.checkShrimp.TabIndex = 14;
            this.checkShrimp.Text = "Shrimp";
            this.checkShrimp.UseVisualStyleBackColor = true;
            // 
            // checkPineApple
            // 
            this.checkPineApple.AutoSize = true;
            this.checkPineApple.Location = new System.Drawing.Point(204, 209);
            this.checkPineApple.Name = "checkPineApple";
            this.checkPineApple.Size = new System.Drawing.Size(168, 33);
            this.checkPineApple.TabIndex = 9;
            this.checkPineApple.Text = "Pine Apple";
            this.checkPineApple.UseVisualStyleBackColor = true;
            // 
            // checkMozzarella
            // 
            this.checkMozzarella.AutoSize = true;
            this.checkMozzarella.Location = new System.Drawing.Point(30, 48);
            this.checkMozzarella.Name = "checkMozzarella";
            this.checkMozzarella.Size = new System.Drawing.Size(168, 33);
            this.checkMozzarella.TabIndex = 0;
            this.checkMozzarella.Text = "Mozzarella";
            this.checkMozzarella.UseVisualStyleBackColor = true;
            // 
            // checkBacon
            // 
            this.checkBacon.AutoSize = true;
            this.checkBacon.Location = new System.Drawing.Point(378, 105);
            this.checkBacon.Name = "checkBacon";
            this.checkBacon.Size = new System.Drawing.Size(112, 33);
            this.checkBacon.TabIndex = 13;
            this.checkBacon.Text = "Bacon";
            this.checkBacon.UseVisualStyleBackColor = true;
            // 
            // checkGorgonzola
            // 
            this.checkGorgonzola.AutoSize = true;
            this.checkGorgonzola.Location = new System.Drawing.Point(204, 262);
            this.checkGorgonzola.Name = "checkGorgonzola";
            this.checkGorgonzola.Size = new System.Drawing.Size(175, 33);
            this.checkGorgonzola.TabIndex = 10;
            this.checkGorgonzola.Text = "Gorgonzola";
            this.checkGorgonzola.UseVisualStyleBackColor = true;
            // 
            // checkAsiago
            // 
            this.checkAsiago.AutoSize = true;
            this.checkAsiago.Location = new System.Drawing.Point(204, 320);
            this.checkAsiago.Name = "checkAsiago";
            this.checkAsiago.Size = new System.Drawing.Size(119, 33);
            this.checkAsiago.TabIndex = 11;
            this.checkAsiago.Text = "Asiago";
            this.checkAsiago.UseVisualStyleBackColor = true;
            // 
            // checkSpinach
            // 
            this.checkSpinach.AutoSize = true;
            this.checkSpinach.Location = new System.Drawing.Point(378, 48);
            this.checkSpinach.Name = "checkSpinach";
            this.checkSpinach.Size = new System.Drawing.Size(134, 33);
            this.checkSpinach.TabIndex = 12;
            this.checkSpinach.Text = "Spinach";
            this.checkSpinach.UseVisualStyleBackColor = true;
            // 
            // panelSnacks
            // 
            this.panelSnacks.AutoScroll = true;
            this.panelSnacks.BackColor = System.Drawing.Color.SandyBrown;
            this.panelSnacks.Controls.Add(this.lblSnacks);
            this.panelSnacks.Controls.Add(this.checkFrenchF);
            this.panelSnacks.Controls.Add(this.checkTurkishB);
            this.panelSnacks.Controls.Add(this.checkOnionR);
            this.panelSnacks.Controls.Add(this.checkChickenW);
            this.panelSnacks.Controls.Add(this.checkCheesyS);
            this.panelSnacks.Controls.Add(this.checkBuffaloW);
            this.panelSnacks.Location = new System.Drawing.Point(831, 25);
            this.panelSnacks.Name = "panelSnacks";
            this.panelSnacks.Size = new System.Drawing.Size(237, 296);
            this.panelSnacks.TabIndex = 11;
            // 
            // lblSnacks
            // 
            this.lblSnacks.AutoSize = true;
            this.lblSnacks.Location = new System.Drawing.Point(57, 11);
            this.lblSnacks.Name = "lblSnacks";
            this.lblSnacks.Size = new System.Drawing.Size(103, 29);
            this.lblSnacks.TabIndex = 6;
            this.lblSnacks.Text = "Snacks";
            // 
            // checkFrenchF
            // 
            this.checkFrenchF.AutoSize = true;
            this.checkFrenchF.Location = new System.Drawing.Point(3, 53);
            this.checkFrenchF.Name = "checkFrenchF";
            this.checkFrenchF.Size = new System.Drawing.Size(188, 33);
            this.checkFrenchF.TabIndex = 0;
            this.checkFrenchF.Text = "French Fries";
            this.checkFrenchF.UseVisualStyleBackColor = true;
            // 
            // checkTurkishB
            // 
            this.checkTurkishB.AutoSize = true;
            this.checkTurkishB.Location = new System.Drawing.Point(3, 247);
            this.checkTurkishB.Name = "checkTurkishB";
            this.checkTurkishB.Size = new System.Drawing.Size(210, 33);
            this.checkTurkishB.TabIndex = 5;
            this.checkTurkishB.Text = "Turkish Bacon";
            this.checkTurkishB.UseVisualStyleBackColor = true;
            // 
            // checkOnionR
            // 
            this.checkOnionR.AutoSize = true;
            this.checkOnionR.Location = new System.Drawing.Point(3, 91);
            this.checkOnionR.Name = "checkOnionR";
            this.checkOnionR.Size = new System.Drawing.Size(171, 33);
            this.checkOnionR.TabIndex = 1;
            this.checkOnionR.Text = "Onion Ring";
            this.checkOnionR.UseVisualStyleBackColor = true;
            // 
            // checkChickenW
            // 
            this.checkChickenW.AutoSize = true;
            this.checkChickenW.Location = new System.Drawing.Point(3, 130);
            this.checkChickenW.Name = "checkChickenW";
            this.checkChickenW.Size = new System.Drawing.Size(204, 33);
            this.checkChickenW.TabIndex = 2;
            this.checkChickenW.Text = "Chicken Wing";
            this.checkChickenW.UseVisualStyleBackColor = true;
            // 
            // checkCheesyS
            // 
            this.checkCheesyS.AutoSize = true;
            this.checkCheesyS.Location = new System.Drawing.Point(3, 208);
            this.checkCheesyS.Name = "checkCheesyS";
            this.checkCheesyS.Size = new System.Drawing.Size(196, 33);
            this.checkCheesyS.TabIndex = 4;
            this.checkCheesyS.Text = "Cheesy Stick";
            this.checkCheesyS.UseVisualStyleBackColor = true;
            // 
            // checkBuffaloW
            // 
            this.checkBuffaloW.AutoSize = true;
            this.checkBuffaloW.Location = new System.Drawing.Point(3, 169);
            this.checkBuffaloW.Name = "checkBuffaloW";
            this.checkBuffaloW.Size = new System.Drawing.Size(191, 33);
            this.checkBuffaloW.TabIndex = 3;
            this.checkBuffaloW.Text = "Buffalo Wing";
            this.checkBuffaloW.UseVisualStyleBackColor = true;
            // 
            // panelCrust
            // 
            this.panelCrust.AutoScroll = true;
            this.panelCrust.BackColor = System.Drawing.Color.SandyBrown;
            this.panelCrust.Controls.Add(this.lblCrust);
            this.panelCrust.Controls.Add(this.radioCrustSquare);
            this.panelCrust.Controls.Add(this.radioCrustClassic);
            this.panelCrust.Controls.Add(this.radioCrustDouble);
            this.panelCrust.Controls.Add(this.radioCrustSausage);
            this.panelCrust.Location = new System.Drawing.Point(548, 25);
            this.panelCrust.Name = "panelCrust";
            this.panelCrust.Size = new System.Drawing.Size(261, 296);
            this.panelCrust.TabIndex = 10;
            // 
            // lblCrust
            // 
            this.lblCrust.AutoSize = true;
            this.lblCrust.Location = new System.Drawing.Point(62, 11);
            this.lblCrust.Name = "lblCrust";
            this.lblCrust.Size = new System.Drawing.Size(78, 29);
            this.lblCrust.TabIndex = 4;
            this.lblCrust.Text = "Crust";
            // 
            // radioCrustSquare
            // 
            this.radioCrustSquare.AutoSize = true;
            this.radioCrustSquare.Location = new System.Drawing.Point(20, 169);
            this.radioCrustSquare.Name = "radioCrustSquare";
            this.radioCrustSquare.Size = new System.Drawing.Size(121, 33);
            this.radioCrustSquare.TabIndex = 3;
            this.radioCrustSquare.TabStop = true;
            this.radioCrustSquare.Text = "Square";
            this.radioCrustSquare.UseVisualStyleBackColor = true;
            // 
            // radioCrustClassic
            // 
            this.radioCrustClassic.AutoSize = true;
            this.radioCrustClassic.Location = new System.Drawing.Point(20, 52);
            this.radioCrustClassic.Name = "radioCrustClassic";
            this.radioCrustClassic.Size = new System.Drawing.Size(124, 33);
            this.radioCrustClassic.TabIndex = 0;
            this.radioCrustClassic.TabStop = true;
            this.radioCrustClassic.Text = "Classic";
            this.radioCrustClassic.UseVisualStyleBackColor = true;
            // 
            // radioCrustDouble
            // 
            this.radioCrustDouble.AutoSize = true;
            this.radioCrustDouble.Location = new System.Drawing.Point(20, 91);
            this.radioCrustDouble.Name = "radioCrustDouble";
            this.radioCrustDouble.Size = new System.Drawing.Size(220, 33);
            this.radioCrustDouble.TabIndex = 1;
            this.radioCrustDouble.TabStop = true;
            this.radioCrustDouble.Text = "Double Cheesy";
            this.radioCrustDouble.UseVisualStyleBackColor = true;
            // 
            // radioCrustSausage
            // 
            this.radioCrustSausage.AutoSize = true;
            this.radioCrustSausage.Location = new System.Drawing.Point(20, 130);
            this.radioCrustSausage.Name = "radioCrustSausage";
            this.radioCrustSausage.Size = new System.Drawing.Size(141, 33);
            this.radioCrustSausage.TabIndex = 2;
            this.radioCrustSausage.TabStop = true;
            this.radioCrustSausage.Text = "Sausage";
            this.radioCrustSausage.UseVisualStyleBackColor = true;
            // 
            // panelSauce
            // 
            this.panelSauce.AutoScroll = true;
            this.panelSauce.BackColor = System.Drawing.Color.SandyBrown;
            this.panelSauce.Controls.Add(this.lblSauce);
            this.panelSauce.Controls.Add(this.radioSauceBerk);
            this.panelSauce.Controls.Add(this.radioSauceRanch);
            this.panelSauce.Controls.Add(this.radioSauceBarbeque);
            this.panelSauce.Controls.Add(this.radioSaucePesto);
            this.panelSauce.Location = new System.Drawing.Point(262, 25);
            this.panelSauce.Name = "panelSauce";
            this.panelSauce.Size = new System.Drawing.Size(249, 296);
            this.panelSauce.TabIndex = 9;
            // 
            // lblSauce
            // 
            this.lblSauce.AutoSize = true;
            this.lblSauce.Location = new System.Drawing.Point(43, 11);
            this.lblSauce.Name = "lblSauce";
            this.lblSauce.Size = new System.Drawing.Size(158, 29);
            this.lblSauce.TabIndex = 4;
            this.lblSauce.Text = "Sauce Type";
            // 
            // radioSauceBerk
            // 
            this.radioSauceBerk.AutoSize = true;
            this.radioSauceBerk.BackColor = System.Drawing.Color.SandyBrown;
            this.radioSauceBerk.Location = new System.Drawing.Point(28, 169);
            this.radioSauceBerk.Name = "radioSauceBerk";
            this.radioSauceBerk.Size = new System.Drawing.Size(209, 33);
            this.radioSauceBerk.TabIndex = 3;
            this.radioSauceBerk.TabStop = true;
            this.radioSauceBerk.Text = "Berk\'s Special";
            this.radioSauceBerk.UseVisualStyleBackColor = false;
            // 
            // radioSauceRanch
            // 
            this.radioSauceRanch.AutoSize = true;
            this.radioSauceRanch.Location = new System.Drawing.Point(28, 52);
            this.radioSauceRanch.Name = "radioSauceRanch";
            this.radioSauceRanch.Size = new System.Drawing.Size(112, 33);
            this.radioSauceRanch.TabIndex = 0;
            this.radioSauceRanch.TabStop = true;
            this.radioSauceRanch.Text = "Ranch";
            this.radioSauceRanch.UseVisualStyleBackColor = true;
            // 
            // radioSauceBarbeque
            // 
            this.radioSauceBarbeque.AutoSize = true;
            this.radioSauceBarbeque.Location = new System.Drawing.Point(28, 91);
            this.radioSauceBarbeque.Name = "radioSauceBarbeque";
            this.radioSauceBarbeque.Size = new System.Drawing.Size(151, 33);
            this.radioSauceBarbeque.TabIndex = 1;
            this.radioSauceBarbeque.TabStop = true;
            this.radioSauceBarbeque.Text = "Barbeque";
            this.radioSauceBarbeque.UseVisualStyleBackColor = true;
            // 
            // radioSaucePesto
            // 
            this.radioSaucePesto.AutoSize = true;
            this.radioSaucePesto.Location = new System.Drawing.Point(28, 130);
            this.radioSaucePesto.Name = "radioSaucePesto";
            this.radioSaucePesto.Size = new System.Drawing.Size(104, 33);
            this.radioSaucePesto.TabIndex = 2;
            this.radioSaucePesto.TabStop = true;
            this.radioSaucePesto.Text = "Pesto";
            this.radioSaucePesto.UseVisualStyleBackColor = true;
            // 
            // panelSize
            // 
            this.panelSize.AutoScroll = true;
            this.panelSize.BackColor = System.Drawing.Color.SandyBrown;
            this.panelSize.Controls.Add(this.lblSize);
            this.panelSize.Controls.Add(this.radioSizeLarge);
            this.panelSize.Controls.Add(this.radioSizeKing);
            this.panelSize.Controls.Add(this.radioSizeMedium);
            this.panelSize.Controls.Add(this.radioSizeSmall);
            this.panelSize.Location = new System.Drawing.Point(16, 25);
            this.panelSize.Name = "panelSize";
            this.panelSize.Size = new System.Drawing.Size(213, 296);
            this.panelSize.TabIndex = 8;
            // 
            // lblSize
            // 
            this.lblSize.AutoSize = true;
            this.lblSize.Location = new System.Drawing.Point(54, 11);
            this.lblSize.Name = "lblSize";
            this.lblSize.Size = new System.Drawing.Size(67, 29);
            this.lblSize.TabIndex = 4;
            this.lblSize.Text = "Size";
            // 
            // radioSizeLarge
            // 
            this.radioSizeLarge.AutoSize = true;
            this.radioSizeLarge.Location = new System.Drawing.Point(17, 130);
            this.radioSizeLarge.Name = "radioSizeLarge";
            this.radioSizeLarge.Size = new System.Drawing.Size(103, 33);
            this.radioSizeLarge.TabIndex = 2;
            this.radioSizeLarge.TabStop = true;
            this.radioSizeLarge.Text = "Large";
            this.radioSizeLarge.UseVisualStyleBackColor = true;
            // 
            // radioSizeKing
            // 
            this.radioSizeKing.AutoSize = true;
            this.radioSizeKing.Location = new System.Drawing.Point(17, 169);
            this.radioSizeKing.Name = "radioSizeKing";
            this.radioSizeKing.Size = new System.Drawing.Size(159, 33);
            this.radioSizeKing.TabIndex = 3;
            this.radioSizeKing.TabStop = true;
            this.radioSizeKing.Text = "King Size!";
            this.radioSizeKing.UseVisualStyleBackColor = true;
            // 
            // radioSizeMedium
            // 
            this.radioSizeMedium.AutoSize = true;
            this.radioSizeMedium.Location = new System.Drawing.Point(17, 91);
            this.radioSizeMedium.Name = "radioSizeMedium";
            this.radioSizeMedium.Size = new System.Drawing.Size(131, 33);
            this.radioSizeMedium.TabIndex = 1;
            this.radioSizeMedium.TabStop = true;
            this.radioSizeMedium.Text = "Medium";
            this.radioSizeMedium.UseVisualStyleBackColor = true;
            // 
            // radioSizeSmall
            // 
            this.radioSizeSmall.AutoSize = true;
            this.radioSizeSmall.Location = new System.Drawing.Point(17, 52);
            this.radioSizeSmall.Name = "radioSizeSmall";
            this.radioSizeSmall.Size = new System.Drawing.Size(104, 33);
            this.radioSizeSmall.TabIndex = 0;
            this.radioSizeSmall.TabStop = true;
            this.radioSizeSmall.Text = "Small";
            this.radioSizeSmall.UseVisualStyleBackColor = true;
            // 
            // groupDrinks
            // 
            this.groupDrinks.BackColor = System.Drawing.Color.SandyBrown;
            this.groupDrinks.Controls.Add(this.textWaterQ);
            this.groupDrinks.Controls.Add(this.text7DaysQ);
            this.groupDrinks.Controls.Add(this.textWineQ);
            this.groupDrinks.Controls.Add(this.textBerkBeerQ);
            this.groupDrinks.Controls.Add(this.textAyranQ);
            this.groupDrinks.Controls.Add(this.textDietCokeQ);
            this.groupDrinks.Controls.Add(this.textCokeQ);
            this.groupDrinks.Controls.Add(this.labelWater);
            this.groupDrinks.Controls.Add(this.label7Days);
            this.groupDrinks.Controls.Add(this.labelWine);
            this.groupDrinks.Controls.Add(this.labelBerkBeer);
            this.groupDrinks.Controls.Add(this.labelAyran);
            this.groupDrinks.Controls.Add(this.labelDietCoke);
            this.groupDrinks.Controls.Add(this.labelCoke);
            this.groupDrinks.Location = new System.Drawing.Point(623, 355);
            this.groupDrinks.Name = "groupDrinks";
            this.groupDrinks.Size = new System.Drawing.Size(389, 447);
            this.groupDrinks.TabIndex = 7;
            this.groupDrinks.TabStop = false;
            this.groupDrinks.Text = "Drinks";
            // 
            // textWaterQ
            // 
            this.textWaterQ.Location = new System.Drawing.Point(208, 364);
            this.textWaterQ.Name = "textWaterQ";
            this.textWaterQ.Size = new System.Drawing.Size(100, 36);
            this.textWaterQ.TabIndex = 13;
            this.textWaterQ.Text = "0";
            this.textWaterQ.Enter += new System.EventHandler(this.textWaterQ_Enter);
            this.textWaterQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textWaterQ_KeyPress);
            this.textWaterQ.Leave += new System.EventHandler(this.textWaterQ_Leave);
            // 
            // text7DaysQ
            // 
            this.text7DaysQ.Location = new System.Drawing.Point(208, 313);
            this.text7DaysQ.Name = "text7DaysQ";
            this.text7DaysQ.Size = new System.Drawing.Size(100, 36);
            this.text7DaysQ.TabIndex = 12;
            this.text7DaysQ.Text = "0";
            this.text7DaysQ.Enter += new System.EventHandler(this.text7DaysQ_Enter);
            this.text7DaysQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text7DaysQ_KeyPress);
            this.text7DaysQ.Leave += new System.EventHandler(this.text7DaysQ_Leave);
            // 
            // textWineQ
            // 
            this.textWineQ.Location = new System.Drawing.Point(208, 255);
            this.textWineQ.Name = "textWineQ";
            this.textWineQ.Size = new System.Drawing.Size(100, 36);
            this.textWineQ.TabIndex = 11;
            this.textWineQ.Text = "0";
            this.textWineQ.Enter += new System.EventHandler(this.textWineQ_Enter);
            this.textWineQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textWineQ_KeyPress);
            this.textWineQ.Leave += new System.EventHandler(this.textWineQ_Leave);
            // 
            // textBerkBeerQ
            // 
            this.textBerkBeerQ.Location = new System.Drawing.Point(208, 202);
            this.textBerkBeerQ.Name = "textBerkBeerQ";
            this.textBerkBeerQ.Size = new System.Drawing.Size(100, 36);
            this.textBerkBeerQ.TabIndex = 10;
            this.textBerkBeerQ.Text = "0";
            this.textBerkBeerQ.Enter += new System.EventHandler(this.textBerkBeerQ_Enter);
            this.textBerkBeerQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBerkBeerQ_KeyPress);
            this.textBerkBeerQ.Leave += new System.EventHandler(this.textBerkBeerQ_Leave);
            // 
            // textAyranQ
            // 
            this.textAyranQ.Location = new System.Drawing.Point(208, 151);
            this.textAyranQ.Name = "textAyranQ";
            this.textAyranQ.Size = new System.Drawing.Size(100, 36);
            this.textAyranQ.TabIndex = 9;
            this.textAyranQ.Text = "0";
            this.textAyranQ.Enter += new System.EventHandler(this.textAyranQ_Enter);
            this.textAyranQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textAyranQ_KeyPress);
            this.textAyranQ.Leave += new System.EventHandler(this.textAyranQ_Leave);
            // 
            // textDietCokeQ
            // 
            this.textDietCokeQ.Location = new System.Drawing.Point(208, 102);
            this.textDietCokeQ.Name = "textDietCokeQ";
            this.textDietCokeQ.Size = new System.Drawing.Size(100, 36);
            this.textDietCokeQ.TabIndex = 8;
            this.textDietCokeQ.Text = "0";
            this.textDietCokeQ.Enter += new System.EventHandler(this.textDietCokeQ_Enter);
            this.textDietCokeQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textDietCokeQ_KeyPress);
            this.textDietCokeQ.Leave += new System.EventHandler(this.textDietCokeQ_Leave);
            // 
            // textCokeQ
            // 
            this.textCokeQ.Location = new System.Drawing.Point(208, 56);
            this.textCokeQ.Name = "textCokeQ";
            this.textCokeQ.Size = new System.Drawing.Size(100, 36);
            this.textCokeQ.TabIndex = 7;
            this.textCokeQ.Text = "0";
            this.textCokeQ.Enter += new System.EventHandler(this.textCokeQ_Enter);
            this.textCokeQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textCokeQ_KeyPress);
            this.textCokeQ.Leave += new System.EventHandler(this.textCokeQ_Leave);
            // 
            // labelWater
            // 
            this.labelWater.AutoSize = true;
            this.labelWater.Location = new System.Drawing.Point(20, 371);
            this.labelWater.Name = "labelWater";
            this.labelWater.Size = new System.Drawing.Size(85, 29);
            this.labelWater.TabIndex = 6;
            this.labelWater.Text = "Water";
            // 
            // label7Days
            // 
            this.label7Days.AutoSize = true;
            this.label7Days.Location = new System.Drawing.Point(20, 320);
            this.label7Days.Name = "label7Days";
            this.label7Days.Size = new System.Drawing.Size(90, 29);
            this.label7Days.TabIndex = 5;
            this.label7Days.Text = "7Days";
            // 
            // labelWine
            // 
            this.labelWine.AutoSize = true;
            this.labelWine.Location = new System.Drawing.Point(20, 262);
            this.labelWine.Name = "labelWine";
            this.labelWine.Size = new System.Drawing.Size(75, 29);
            this.labelWine.TabIndex = 4;
            this.labelWine.Text = "Wine";
            // 
            // labelBerkBeer
            // 
            this.labelBerkBeer.AutoSize = true;
            this.labelBerkBeer.Location = new System.Drawing.Point(20, 209);
            this.labelBerkBeer.Name = "labelBerkBeer";
            this.labelBerkBeer.Size = new System.Drawing.Size(154, 29);
            this.labelBerkBeer.TabIndex = 3;
            this.labelBerkBeer.Text = "Berk\'s Beer";
            // 
            // labelAyran
            // 
            this.labelAyran.AutoSize = true;
            this.labelAyran.Location = new System.Drawing.Point(20, 158);
            this.labelAyran.Name = "labelAyran";
            this.labelAyran.Size = new System.Drawing.Size(84, 29);
            this.labelAyran.TabIndex = 2;
            this.labelAyran.Text = "Ayran";
            // 
            // labelDietCoke
            // 
            this.labelDietCoke.AutoSize = true;
            this.labelDietCoke.Location = new System.Drawing.Point(20, 109);
            this.labelDietCoke.Name = "labelDietCoke";
            this.labelDietCoke.Size = new System.Drawing.Size(133, 29);
            this.labelDietCoke.TabIndex = 1;
            this.labelDietCoke.Text = "Diet Coke";
            // 
            // labelCoke
            // 
            this.labelCoke.AutoSize = true;
            this.labelCoke.Location = new System.Drawing.Point(20, 63);
            this.labelCoke.Name = "labelCoke";
            this.labelCoke.Size = new System.Drawing.Size(76, 29);
            this.labelCoke.TabIndex = 0;
            this.labelCoke.Text = "Coke";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(574, 831);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(257, 51);
            this.btnConfirm.TabIndex = 5;
            this.btnConfirm.Text = "CONFIRMATION";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(262, 831);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(261, 51);
            this.btnClear.TabIndex = 4;
            this.btnClear.Text = "CLEAR";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // tabConfirm
            // 
            this.tabConfirm.BackColor = System.Drawing.Color.Tomato;
            this.tabConfirm.Controls.Add(this.textTotalAmount);
            this.tabConfirm.Controls.Add(this.labelTotalAmount);
            this.tabConfirm.Controls.Add(this.btnPayAndEat);
            this.tabConfirm.Controls.Add(this.btnClear2);
            this.tabConfirm.Controls.Add(this.btnGoBack);
            this.tabConfirm.Controls.Add(this.listOrder);
            this.tabConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabConfirm.Location = new System.Drawing.Point(4, 38);
            this.tabConfirm.Name = "tabConfirm";
            this.tabConfirm.Padding = new System.Windows.Forms.Padding(3);
            this.tabConfirm.Size = new System.Drawing.Size(1083, 1122);
            this.tabConfirm.TabIndex = 1;
            this.tabConfirm.Text = "Confirmation";
            // 
            // textTotalAmount
            // 
            this.textTotalAmount.Location = new System.Drawing.Point(471, 671);
            this.textTotalAmount.Name = "textTotalAmount";
            this.textTotalAmount.Size = new System.Drawing.Size(187, 36);
            this.textTotalAmount.TabIndex = 5;
            // 
            // labelTotalAmount
            // 
            this.labelTotalAmount.AutoSize = true;
            this.labelTotalAmount.Location = new System.Drawing.Point(267, 671);
            this.labelTotalAmount.Name = "labelTotalAmount";
            this.labelTotalAmount.Size = new System.Drawing.Size(184, 29);
            this.labelTotalAmount.TabIndex = 4;
            this.labelTotalAmount.Text = "Total Amount:";
            // 
            // btnPayAndEat
            // 
            this.btnPayAndEat.Location = new System.Drawing.Point(689, 765);
            this.btnPayAndEat.Name = "btnPayAndEat";
            this.btnPayAndEat.Size = new System.Drawing.Size(267, 67);
            this.btnPayAndEat.TabIndex = 3;
            this.btnPayAndEat.Text = "PAY AND EAT!";
            this.btnPayAndEat.UseVisualStyleBackColor = true;
            this.btnPayAndEat.Click += new System.EventHandler(this.btnPayAndEat_Click);
            // 
            // btnClear2
            // 
            this.btnClear2.Location = new System.Drawing.Point(368, 765);
            this.btnClear2.Name = "btnClear2";
            this.btnClear2.Size = new System.Drawing.Size(250, 67);
            this.btnClear2.TabIndex = 2;
            this.btnClear2.Text = "CLEAR";
            this.btnClear2.UseVisualStyleBackColor = true;
            this.btnClear2.Click += new System.EventHandler(this.BtnClear2_Click);
            // 
            // btnGoBack
            // 
            this.btnGoBack.Location = new System.Drawing.Point(15, 765);
            this.btnGoBack.Name = "btnGoBack";
            this.btnGoBack.Size = new System.Drawing.Size(229, 67);
            this.btnGoBack.TabIndex = 1;
            this.btnGoBack.Text = "GO BACK";
            this.btnGoBack.UseVisualStyleBackColor = true;
            // 
            // listOrder
            // 
            this.listOrder.BackColor = System.Drawing.Color.SandyBrown;
            this.listOrder.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnItems,
            this.columnQuantity,
            this.columnPrice});
            this.listOrder.FullRowSelect = true;
            this.listOrder.Location = new System.Drawing.Point(6, 6);
            this.listOrder.Name = "listOrder";
            this.listOrder.Size = new System.Drawing.Size(1040, 635);
            this.listOrder.TabIndex = 0;
            this.listOrder.UseCompatibleStateImageBehavior = false;
            this.listOrder.View = System.Windows.Forms.View.Details;
            // 
            // columnItems
            // 
            this.columnItems.Text = "Selected Items";
            this.columnItems.Width = 304;
            // 
            // columnQuantity
            // 
            this.columnQuantity.Text = "Quantity";
            this.columnQuantity.Width = 297;
            // 
            // columnPrice
            // 
            this.columnPrice.Text = "Price";
            this.columnPrice.Width = 741;
            // 
            // tabPayment
            // 
            this.tabPayment.BackColor = System.Drawing.Color.Tomato;
            this.tabPayment.Controls.Add(this.btnPayNOrder);
            this.tabPayment.Controls.Add(this.btnGoBack2);
            this.tabPayment.Controls.Add(this.groupPaymentField);
            this.tabPayment.Controls.Add(this.labelFieldMFilled);
            this.tabPayment.Controls.Add(this.groupInfoFİeld);
            this.tabPayment.Location = new System.Drawing.Point(4, 38);
            this.tabPayment.Name = "tabPayment";
            this.tabPayment.Padding = new System.Windows.Forms.Padding(3);
            this.tabPayment.Size = new System.Drawing.Size(1083, 1122);
            this.tabPayment.TabIndex = 2;
            this.tabPayment.Text = "Payment";
            // 
            // btnPayNOrder
            // 
            this.btnPayNOrder.Location = new System.Drawing.Point(600, 993);
            this.btnPayNOrder.Name = "btnPayNOrder";
            this.btnPayNOrder.Size = new System.Drawing.Size(342, 68);
            this.btnPayNOrder.TabIndex = 4;
            this.btnPayNOrder.Text = "PAY AND ORDER!";
            this.btnPayNOrder.UseVisualStyleBackColor = true;
            this.btnPayNOrder.Click += new System.EventHandler(this.BtnPayNOrder_Click);
            // 
            // btnGoBack2
            // 
            this.btnGoBack2.Location = new System.Drawing.Point(172, 993);
            this.btnGoBack2.Name = "btnGoBack2";
            this.btnGoBack2.Size = new System.Drawing.Size(325, 68);
            this.btnGoBack2.TabIndex = 3;
            this.btnGoBack2.Text = "GO BACK";
            this.btnGoBack2.UseVisualStyleBackColor = true;
            this.btnGoBack2.Click += new System.EventHandler(this.btnGoBack2_Click);
            // 
            // groupPaymentField
            // 
            this.groupPaymentField.BackColor = System.Drawing.Color.SandyBrown;
            this.groupPaymentField.Controls.Add(this.pictureBox2);
            this.groupPaymentField.Controls.Add(this.pictureBox1);
            this.groupPaymentField.Controls.Add(this.textBerkCoupon);
            this.groupPaymentField.Controls.Add(this.textTotalAmount2);
            this.groupPaymentField.Controls.Add(this.textCvc);
            this.groupPaymentField.Controls.Add(this.textCardNo);
            this.groupPaymentField.Controls.Add(this.textCardOwner);
            this.groupPaymentField.Controls.Add(this.comboPaymentMethod);
            this.groupPaymentField.Controls.Add(this.labelBerkCoupon);
            this.groupPaymentField.Controls.Add(this.labelTotalAmount2);
            this.groupPaymentField.Controls.Add(this.labelCvc);
            this.groupPaymentField.Controls.Add(this.labelCardNo);
            this.groupPaymentField.Controls.Add(this.labelCardOwner);
            this.groupPaymentField.Controls.Add(this.labelPaymentMethod);
            this.groupPaymentField.Location = new System.Drawing.Point(26, 509);
            this.groupPaymentField.Name = "groupPaymentField";
            this.groupPaymentField.Size = new System.Drawing.Size(996, 433);
            this.groupPaymentField.TabIndex = 2;
            this.groupPaymentField.TabStop = false;
            this.groupPaymentField.Text = "Payment Field";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PizzaOrderingSystem.Properties.Resources.mastercard;
            this.pictureBox2.Location = new System.Drawing.Point(709, 40);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PizzaOrderingSystem.Properties.Resources.visa;
            this.pictureBox1.Location = new System.Drawing.Point(709, 40);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // textBerkCoupon
            // 
            this.textBerkCoupon.Location = new System.Drawing.Point(373, 345);
            this.textBerkCoupon.Name = "textBerkCoupon";
            this.textBerkCoupon.Size = new System.Drawing.Size(543, 36);
            this.textBerkCoupon.TabIndex = 11;
            // 
            // textTotalAmount2
            // 
            this.textTotalAmount2.Location = new System.Drawing.Point(373, 291);
            this.textTotalAmount2.Name = "textTotalAmount2";
            this.textTotalAmount2.Size = new System.Drawing.Size(543, 36);
            this.textTotalAmount2.TabIndex = 10;
            // 
            // textCvc
            // 
            this.textCvc.Location = new System.Drawing.Point(373, 230);
            this.textCvc.Name = "textCvc";
            this.textCvc.Size = new System.Drawing.Size(543, 36);
            this.textCvc.TabIndex = 9;
            this.textCvc.Text = "Enter Cvc";
            this.textCvc.Enter += new System.EventHandler(this.textCvc_Enter);
            this.textCvc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textCvc_KeyPress);
            this.textCvc.Leave += new System.EventHandler(this.textCvc_Leave);
            // 
            // textCardNo
            // 
            this.textCardNo.Location = new System.Drawing.Point(373, 171);
            this.textCardNo.Name = "textCardNo";
            this.textCardNo.Size = new System.Drawing.Size(543, 36);
            this.textCardNo.TabIndex = 8;
            this.textCardNo.Text = "Enter Card Number";
            this.textCardNo.Enter += new System.EventHandler(this.textCardNo_Enter);
            this.textCardNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textCardNo_KeyPress);
            this.textCardNo.Leave += new System.EventHandler(this.textCardNo_Leave);
            // 
            // textCardOwner
            // 
            this.textCardOwner.Location = new System.Drawing.Point(373, 109);
            this.textCardOwner.Name = "textCardOwner";
            this.textCardOwner.Size = new System.Drawing.Size(543, 36);
            this.textCardOwner.TabIndex = 7;
            this.textCardOwner.Text = "Enter Card\'s Owner Full Name";
            this.textCardOwner.Enter += new System.EventHandler(this.textCardOwner_Enter);
            this.textCardOwner.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textCardOwner_KeyPress);
            this.textCardOwner.Leave += new System.EventHandler(this.textCardOwner_Leave);
            // 
            // comboPaymentMethod
            // 
            this.comboPaymentMethod.FormattingEnabled = true;
            this.comboPaymentMethod.Items.AddRange(new object[] {
            "Cash",
            "Credit Card",
            "Debit Card"});
            this.comboPaymentMethod.Location = new System.Drawing.Point(373, 53);
            this.comboPaymentMethod.Name = "comboPaymentMethod";
            this.comboPaymentMethod.Size = new System.Drawing.Size(250, 37);
            this.comboPaymentMethod.TabIndex = 6;
            // 
            // labelBerkCoupon
            // 
            this.labelBerkCoupon.AutoSize = true;
            this.labelBerkCoupon.Location = new System.Drawing.Point(19, 352);
            this.labelBerkCoupon.Name = "labelBerkCoupon";
            this.labelBerkCoupon.Size = new System.Drawing.Size(199, 29);
            this.labelBerkCoupon.TabIndex = 5;
            this.labelBerkCoupon.Text = "Berk\'s Coupon:";
            // 
            // labelTotalAmount2
            // 
            this.labelTotalAmount2.AutoSize = true;
            this.labelTotalAmount2.Location = new System.Drawing.Point(19, 298);
            this.labelTotalAmount2.Name = "labelTotalAmount2";
            this.labelTotalAmount2.Size = new System.Drawing.Size(184, 29);
            this.labelTotalAmount2.TabIndex = 4;
            this.labelTotalAmount2.Text = "Total Amount:";
            // 
            // labelCvc
            // 
            this.labelCvc.AutoSize = true;
            this.labelCvc.Location = new System.Drawing.Point(19, 237);
            this.labelCvc.Name = "labelCvc";
            this.labelCvc.Size = new System.Drawing.Size(79, 29);
            this.labelCvc.TabIndex = 3;
            this.labelCvc.Text = "*Cvc:";
            // 
            // labelCardNo
            // 
            this.labelCardNo.AutoSize = true;
            this.labelCardNo.Location = new System.Drawing.Point(19, 178);
            this.labelCardNo.Name = "labelCardNo";
            this.labelCardNo.Size = new System.Drawing.Size(194, 29);
            this.labelCardNo.TabIndex = 2;
            this.labelCardNo.Text = "*Card Number:";
            // 
            // labelCardOwner
            // 
            this.labelCardOwner.AutoSize = true;
            this.labelCardOwner.Location = new System.Drawing.Point(19, 116);
            this.labelCardOwner.Name = "labelCardOwner";
            this.labelCardOwner.Size = new System.Drawing.Size(309, 29);
            this.labelCardOwner.TabIndex = 1;
            this.labelCardOwner.Text = "*Card Owner Full Name:";
            // 
            // labelPaymentMethod
            // 
            this.labelPaymentMethod.AutoSize = true;
            this.labelPaymentMethod.Location = new System.Drawing.Point(19, 61);
            this.labelPaymentMethod.Name = "labelPaymentMethod";
            this.labelPaymentMethod.Size = new System.Drawing.Size(238, 29);
            this.labelPaymentMethod.TabIndex = 0;
            this.labelPaymentMethod.Text = "*Payment Method:";
            // 
            // labelFieldMFilled
            // 
            this.labelFieldMFilled.AutoSize = true;
            this.labelFieldMFilled.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.labelFieldMFilled.Location = new System.Drawing.Point(335, 28);
            this.labelFieldMFilled.Name = "labelFieldMFilled";
            this.labelFieldMFilled.Size = new System.Drawing.Size(288, 29);
            this.labelFieldMFilled.TabIndex = 1;
            this.labelFieldMFilled.Text = "* FIELD MUST FILLED";
            // 
            // groupInfoFİeld
            // 
            this.groupInfoFİeld.BackColor = System.Drawing.Color.SandyBrown;
            this.groupInfoFİeld.Controls.Add(this.textStreet);
            this.groupInfoFİeld.Controls.Add(this.textPostCode);
            this.groupInfoFİeld.Controls.Add(this.textPhone);
            this.groupInfoFİeld.Controls.Add(this.textAddress);
            this.groupInfoFİeld.Controls.Add(this.textSurname);
            this.groupInfoFİeld.Controls.Add(this.textName);
            this.groupInfoFİeld.Controls.Add(this.labelStreet);
            this.groupInfoFİeld.Controls.Add(this.labelPostCode);
            this.groupInfoFİeld.Controls.Add(this.labelPhone);
            this.groupInfoFİeld.Controls.Add(this.labelAddress);
            this.groupInfoFİeld.Controls.Add(this.labelSurname);
            this.groupInfoFİeld.Controls.Add(this.labelName);
            this.groupInfoFİeld.Location = new System.Drawing.Point(26, 76);
            this.groupInfoFİeld.Name = "groupInfoFİeld";
            this.groupInfoFİeld.Size = new System.Drawing.Size(996, 397);
            this.groupInfoFİeld.TabIndex = 0;
            this.groupInfoFİeld.TabStop = false;
            this.groupInfoFİeld.Text = "Information Field";
            // 
            // textStreet
            // 
            this.textStreet.Location = new System.Drawing.Point(278, 340);
            this.textStreet.Name = "textStreet";
            this.textStreet.Size = new System.Drawing.Size(695, 36);
            this.textStreet.TabIndex = 11;
            this.textStreet.Text = "Enter Your Street";
            this.textStreet.Enter += new System.EventHandler(this.textStreet_Enter);
            this.textStreet.Leave += new System.EventHandler(this.textStreet_Leave);
            // 
            // textPostCode
            // 
            this.textPostCode.Location = new System.Drawing.Point(278, 285);
            this.textPostCode.Name = "textPostCode";
            this.textPostCode.Size = new System.Drawing.Size(695, 36);
            this.textPostCode.TabIndex = 10;
            this.textPostCode.Text = "Enter Your Post Code";
            this.textPostCode.Enter += new System.EventHandler(this.textPostCode_Enter);
            this.textPostCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textPostCode_KeyPress);
            this.textPostCode.Leave += new System.EventHandler(this.textPostCode_Leave);
            // 
            // textPhone
            // 
            this.textPhone.Location = new System.Drawing.Point(278, 229);
            this.textPhone.Name = "textPhone";
            this.textPhone.Size = new System.Drawing.Size(695, 36);
            this.textPhone.TabIndex = 9;
            this.textPhone.Text = "Enter Your Phone Number";
            this.textPhone.Enter += new System.EventHandler(this.textPhone_Enter);
            this.textPhone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textPhone_KeyPress);
            this.textPhone.Leave += new System.EventHandler(this.textPhone_Leave);
            // 
            // textAddress
            // 
            this.textAddress.Location = new System.Drawing.Point(278, 172);
            this.textAddress.Name = "textAddress";
            this.textAddress.Size = new System.Drawing.Size(695, 36);
            this.textAddress.TabIndex = 8;
            this.textAddress.Text = "Enter Your Address";
            this.textAddress.Enter += new System.EventHandler(this.textAddress_Enter);
            this.textAddress.Leave += new System.EventHandler(this.textAddress_Leave);
            // 
            // textSurname
            // 
            this.textSurname.Location = new System.Drawing.Point(278, 114);
            this.textSurname.Name = "textSurname";
            this.textSurname.Size = new System.Drawing.Size(695, 36);
            this.textSurname.TabIndex = 7;
            this.textSurname.Text = "Enter Your Surname";
            this.textSurname.Enter += new System.EventHandler(this.textSurname_Enter);
            this.textSurname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textSurname_KeyPress);
            this.textSurname.Leave += new System.EventHandler(this.textSurname_Leave);
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(278, 54);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(695, 36);
            this.textName.TabIndex = 6;
            this.textName.Text = "Enter Your Name";
            this.textName.Enter += new System.EventHandler(this.textName_Enter);
            this.textName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textName_KeyPress);
            this.textName.Leave += new System.EventHandler(this.textName_Leave);
            // 
            // labelStreet
            // 
            this.labelStreet.AutoSize = true;
            this.labelStreet.Location = new System.Drawing.Point(24, 347);
            this.labelStreet.Name = "labelStreet";
            this.labelStreet.Size = new System.Drawing.Size(94, 29);
            this.labelStreet.TabIndex = 5;
            this.labelStreet.Text = "Street:";
            // 
            // labelPostCode
            // 
            this.labelPostCode.AutoSize = true;
            this.labelPostCode.Location = new System.Drawing.Point(24, 285);
            this.labelPostCode.Name = "labelPostCode";
            this.labelPostCode.Size = new System.Drawing.Size(159, 29);
            this.labelPostCode.TabIndex = 4;
            this.labelPostCode.Text = "*Post Code:";
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Location = new System.Drawing.Point(24, 229);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(214, 29);
            this.labelPhone.TabIndex = 3;
            this.labelPhone.Text = "*Phone Number:";
            // 
            // labelAddress
            // 
            this.labelAddress.AutoSize = true;
            this.labelAddress.Location = new System.Drawing.Point(24, 172);
            this.labelAddress.Name = "labelAddress";
            this.labelAddress.Size = new System.Drawing.Size(132, 29);
            this.labelAddress.TabIndex = 2;
            this.labelAddress.Text = "*Address:";
            // 
            // labelSurname
            // 
            this.labelSurname.AutoSize = true;
            this.labelSurname.Location = new System.Drawing.Point(24, 114);
            this.labelSurname.Name = "labelSurname";
            this.labelSurname.Size = new System.Drawing.Size(142, 29);
            this.labelSurname.TabIndex = 1;
            this.labelSurname.Text = "*Surname:";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(24, 61);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(104, 29);
            this.labelName.TabIndex = 0;
            this.labelName.Text = "*Name:";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Tomato;
            this.tabPage1.Controls.Add(this.richTextBox5);
            this.tabPage1.Controls.Add(this.richTextBox4);
            this.tabPage1.Controls.Add(this.richTextBox3);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.label25);
            this.tabPage1.Controls.Add(this.richTextBox2);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.richTextBox1);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Location = new System.Drawing.Point(4, 38);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1083, 1122);
            this.tabPage1.TabIndex = 3;
            this.tabPage1.Text = "Price List";
            // 
            // richTextBox5
            // 
            this.richTextBox5.BackColor = System.Drawing.Color.SandyBrown;
            this.richTextBox5.Location = new System.Drawing.Point(200, 466);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.Size = new System.Drawing.Size(292, 220);
            this.richTextBox5.TabIndex = 10;
            this.richTextBox5.Text = "Coke 3TL\nDiet Coke 3TL\nAyran 2TL\nBerk\'s Beer 8TL\nWine 25TL\n7Days 3TL\nWater 2TL";
            // 
            // richTextBox4
            // 
            this.richTextBox4.BackColor = System.Drawing.Color.SandyBrown;
            this.richTextBox4.Location = new System.Drawing.Point(635, 244);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(304, 209);
            this.richTextBox4.TabIndex = 9;
            this.richTextBox4.Text = "French Fries 5TL\nOnion Ring 5TL\nChicken Wing 8TL\nBuffalo Wing 8TL\nCheesy Stick 6T" +
    "L\nTurkish Bacon 15TL";
            // 
            // richTextBox3
            // 
            this.richTextBox3.BackColor = System.Drawing.Color.SandyBrown;
            this.richTextBox3.Location = new System.Drawing.Point(200, 241);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(292, 137);
            this.richTextBox3.TabIndex = 8;
            this.richTextBox3.Text = "Classic 1TL\nDouble Cheesy 2TL\nSausage 3TL\nSquare 2TL";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(49, 466);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(99, 29);
            this.label27.TabIndex = 6;
            this.label27.Text = "Drinks:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(518, 241);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(111, 29);
            this.label26.TabIndex = 5;
            this.label26.Text = "Snacks:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(49, 244);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(86, 29);
            this.label25.TabIndex = 4;
            this.label25.Text = "Crust:";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.SandyBrown;
            this.richTextBox2.Location = new System.Drawing.Point(635, 45);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(304, 137);
            this.richTextBox2.TabIndex = 3;
            this.richTextBox2.Text = "Ranch 3 TL\nBarbeque 3TL\nPesto 3TL\nBerk\'s Special 5TL";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(522, 45);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(98, 29);
            this.label24.TabIndex = 2;
            this.label24.Text = "Sauce:";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.SandyBrown;
            this.richTextBox1.Location = new System.Drawing.Point(200, 42);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(292, 140);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "Small 10 TL\nMedium 15 TL\nLarge 20 TL\nKing Size! 25TL";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(30, 45);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(151, 29);
            this.label23.TabIndex = 0;
            this.label23.Text = "Pizza Size:";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Tomato;
            this.tabPage2.Controls.Add(this.textPassword);
            this.tabPage2.Controls.Add(this.textUserName);
            this.tabPage2.Controls.Add(this.label29);
            this.tabPage2.Controls.Add(this.label28);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Location = new System.Drawing.Point(4, 38);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1083, 1122);
            this.tabPage2.TabIndex = 4;
            this.tabPage2.Text = "Admin";
            // 
            // textPassword
            // 
            this.textPassword.Location = new System.Drawing.Point(217, 108);
            this.textPassword.Name = "textPassword";
            this.textPassword.Size = new System.Drawing.Size(205, 36);
            this.textPassword.TabIndex = 4;
            // 
            // textUserName
            // 
            this.textUserName.Location = new System.Drawing.Point(217, 41);
            this.textUserName.Name = "textUserName";
            this.textUserName.Size = new System.Drawing.Size(205, 36);
            this.textUserName.TabIndex = 3;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(35, 108);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(140, 29);
            this.label29.TabIndex = 2;
            this.label29.Text = "Password:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(35, 48);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(158, 29);
            this.label28.TabIndex = 1;
            this.label28.Text = "User Name:";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(24, 170);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(299, 75);
            this.button7.TabIndex = 0;
            this.button7.Text = "Go To Admin Panel";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Sienna;
            this.ClientSize = new System.Drawing.Size(1172, 1037);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.tabControl1.ResumeLayout(false);
            this.tabOrder.ResumeLayout(false);
            this.panelToppings.ResumeLayout(false);
            this.panelToppings.PerformLayout();
            this.panelSnacks.ResumeLayout(false);
            this.panelSnacks.PerformLayout();
            this.panelCrust.ResumeLayout(false);
            this.panelCrust.PerformLayout();
            this.panelSauce.ResumeLayout(false);
            this.panelSauce.PerformLayout();
            this.panelSize.ResumeLayout(false);
            this.panelSize.PerformLayout();
            this.groupDrinks.ResumeLayout(false);
            this.groupDrinks.PerformLayout();
            this.tabConfirm.ResumeLayout(false);
            this.tabConfirm.PerformLayout();
            this.tabPayment.ResumeLayout(false);
            this.tabPayment.PerformLayout();
            this.groupPaymentField.ResumeLayout(false);
            this.groupPaymentField.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupInfoFİeld.ResumeLayout(false);
            this.groupInfoFİeld.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabOrder;
        private System.Windows.Forms.RadioButton radioSauceBerk;
        private System.Windows.Forms.RadioButton radioSaucePesto;
        private System.Windows.Forms.RadioButton radioSauceBarbeque;
        private System.Windows.Forms.RadioButton radioSauceRanch;
        private System.Windows.Forms.RadioButton radioSizeKing;
        private System.Windows.Forms.RadioButton radioSizeLarge;
        private System.Windows.Forms.RadioButton radioSizeMedium;
        private System.Windows.Forms.RadioButton radioSizeSmall;
        private System.Windows.Forms.TabPage tabConfirm;
        private System.Windows.Forms.TabPage tabPayment;
        private System.Windows.Forms.RadioButton radioCrustClassic;
        private System.Windows.Forms.RadioButton radioCrustSquare;
        private System.Windows.Forms.RadioButton radioCrustSausage;
        private System.Windows.Forms.RadioButton radioCrustDouble;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label labelToppings;
        private System.Windows.Forms.CheckBox checkTuna;
        private System.Windows.Forms.CheckBox checkOlive;
        private System.Windows.Forms.CheckBox checkBelPaese;
        private System.Windows.Forms.CheckBox checkShrimp;
        private System.Windows.Forms.CheckBox checkBacon;
        private System.Windows.Forms.CheckBox checkSpinach;
        private System.Windows.Forms.CheckBox checkAsiago;
        private System.Windows.Forms.CheckBox checkGorgonzola;
        private System.Windows.Forms.CheckBox checkPineApple;
        private System.Windows.Forms.CheckBox checkChicken;
        private System.Windows.Forms.CheckBox checkAnchovies;
        private System.Windows.Forms.CheckBox checkJalepeno;
        private System.Windows.Forms.CheckBox checkMushroom;
        private System.Windows.Forms.CheckBox checkPepperoni;
        private System.Windows.Forms.CheckBox checkPepper;
        private System.Windows.Forms.CheckBox checkBeef;
        private System.Windows.Forms.CheckBox checkOnion;
        private System.Windows.Forms.CheckBox checkMozzarella;
        public System.Windows.Forms.ListView listOrder;
        private System.Windows.Forms.GroupBox groupDrinks;
        private System.Windows.Forms.TextBox textWaterQ;
        private System.Windows.Forms.TextBox text7DaysQ;
        private System.Windows.Forms.TextBox textWineQ;
        private System.Windows.Forms.TextBox textBerkBeerQ;
        private System.Windows.Forms.TextBox textAyranQ;
        private System.Windows.Forms.TextBox textDietCokeQ;
        private System.Windows.Forms.TextBox textCokeQ;
        private System.Windows.Forms.Label labelWater;
        private System.Windows.Forms.Label label7Days;
        private System.Windows.Forms.Label labelWine;
        private System.Windows.Forms.Label labelBerkBeer;
        private System.Windows.Forms.Label labelAyran;
        private System.Windows.Forms.Label labelDietCoke;
        private System.Windows.Forms.Label labelCoke;
        private System.Windows.Forms.CheckBox checkTurkishB;
        private System.Windows.Forms.CheckBox checkCheesyS;
        private System.Windows.Forms.CheckBox checkBuffaloW;
        private System.Windows.Forms.CheckBox checkChickenW;
        private System.Windows.Forms.CheckBox checkOnionR;
        private System.Windows.Forms.CheckBox checkFrenchF;
        private System.Windows.Forms.ColumnHeader columnItems;
        private System.Windows.Forms.ColumnHeader columnPrice;
        private System.Windows.Forms.TextBox textTotalAmount;
        private System.Windows.Forms.Label labelTotalAmount;
        private System.Windows.Forms.Button btnPayAndEat;
        private System.Windows.Forms.Button btnClear2;
        private System.Windows.Forms.Button btnGoBack;
        private System.Windows.Forms.Label labelFieldMFilled;
        private System.Windows.Forms.GroupBox groupInfoFİeld;
        private System.Windows.Forms.TextBox textStreet;
        private System.Windows.Forms.TextBox textPostCode;
        private System.Windows.Forms.TextBox textPhone;
        private System.Windows.Forms.TextBox textAddress;
        private System.Windows.Forms.TextBox textSurname;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.Label labelStreet;
        private System.Windows.Forms.Label labelPostCode;
        private System.Windows.Forms.Label labelPhone;
        private System.Windows.Forms.Label labelAddress;
        private System.Windows.Forms.Label labelSurname;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.GroupBox groupPaymentField;
        private System.Windows.Forms.TextBox textBerkCoupon;
        private System.Windows.Forms.TextBox textTotalAmount2;
        private System.Windows.Forms.TextBox textCvc;
        private System.Windows.Forms.TextBox textCardNo;
        private System.Windows.Forms.TextBox textCardOwner;
        private System.Windows.Forms.ComboBox comboPaymentMethod;
        private System.Windows.Forms.Label labelBerkCoupon;
        private System.Windows.Forms.Label labelTotalAmount2;
        private System.Windows.Forms.Label labelCvc;
        private System.Windows.Forms.Label labelCardNo;
        private System.Windows.Forms.Label labelCardOwner;
        private System.Windows.Forms.Label labelPaymentMethod;
        private System.Windows.Forms.Button btnPayNOrder;
        private System.Windows.Forms.Button btnGoBack2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textPassword;
        private System.Windows.Forms.TextBox textUserName;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ColumnHeader columnQuantity;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.Panel panelSize;
        private System.Windows.Forms.Label lblSize;
        public System.Windows.Forms.Panel panelToppings;
        public System.Windows.Forms.Panel panelSnacks;
        private System.Windows.Forms.Label lblSnacks;
        public System.Windows.Forms.Panel panelCrust;
        private System.Windows.Forms.Label lblCrust;
        public System.Windows.Forms.Panel panelSauce;
        private System.Windows.Forms.Label lblSauce;
    }
}

