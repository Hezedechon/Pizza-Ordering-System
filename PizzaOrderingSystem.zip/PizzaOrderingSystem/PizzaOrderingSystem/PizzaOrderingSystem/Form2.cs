﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PizzaOrderingSystem
{
    public partial class Form2 : Form
    {
        public static Form2 _instance2;
        public Form2()
        {
                    
            InitializeComponent();
            _instance2 = this;

        }
        
        RadioButton rbtnSize = new RadioButton();
        RadioButton rbtnSauce = new RadioButton();
        RadioButton rbtnCrust = new RadioButton();
        CheckBox chcSnack = new CheckBox();

        int rowSize = 0;
        private void btnAddNewSize_Click(object sender, EventArgs e)
        {
            //rowSize = rowSize + 30;
            rbtnSize = new RadioButton();
            rbtnSize.Text = txtSizeName.Text;
            rbtnSize.Size = new Size(104, 33);
            rbtnSize.Location = new Point(0,Form1._instance.panelSize.Controls.Count * rbtnSize.Height);

           

            Form1._instance.panelSize.Controls.Add(rbtnSize);
                
        }

        private void BtnAddNewSauce_Click(object sender, EventArgs e)
        {
            rbtnSauce = new RadioButton();
            rbtnSauce.Text = txtSauceName.Text;
            rbtnSauce.Size = new Size(104, 33);
            rbtnSauce.Location = new Point(15, Form1._instance.panelSauce.Controls.Count * rbtnSauce.Height);

            Form1._instance.panelSauce.Controls.Add(rbtnSauce);
        }

        public void ChooseDynamicSize()
        {

            if (rbtnSize.Checked == true)
            {
                Form1._instance.pizzaSize = new ListViewItem(txtSizeName.Text);
                Form1._instance.pizzaSize.SubItems.Add("");
                Form1._instance.pizzaSize.SubItems.Add(txtSizeCost.Text);
                Form1._instance.listOrder.Items.Add(Form1._instance.pizzaSize);
            }
            else
                return;



            //else
            //    return;
            //if (rbtnSauce.Checked == true)
            //{
            //    Form1._instance.pizzaSize = new ListViewItem(txtSauceName.Text);
            //    Form1._instance.pizzaSize.SubItems.Add("");
            //    Form1._instance.pizzaSize.SubItems.Add(txtSauceCost.Text);
            //    Form1._instance.listOrder.Items.Add(Form1._instance.pizzaSauce);
            //}
        }
        int rowSauce;
        public void ChooseDynamicSauce()
        {

            if (rbtnSauce.Checked == true)
            {
                Form1._instance.pizzaSauce = new ListViewItem(txtSauceName.Text);
                Form1._instance.pizzaSauce.SubItems.Add("");
                Form1._instance.pizzaSauce.SubItems.Add(txtSauceCost.Text);
                Form1._instance.listOrder.Items.Add(Form1._instance.pizzaSauce);
            }
        }

        private void BtnAddNewCrust_Click(object sender, EventArgs e)
        {
            rbtnCrust = new RadioButton();
            rbtnCrust.Text = txtCrustName.Text;
            rbtnCrust.Size = new Size(104, 33);
            rbtnCrust.Location = new Point(15, Form1._instance.panelCrust.Controls.Count * rbtnCrust.Height);

            Form1._instance.panelCrust.Controls.Add(rbtnCrust);
        }
        public void ChooseDynamicCrust()
        {
            if (rbtnCrust.Checked == true)
            {
                Form1._instance.pizzaCrust = new ListViewItem(txtCrustName.Text);
                Form1._instance.pizzaCrust.SubItems.Add("");
                Form1._instance.pizzaCrust.SubItems.Add(txtCrustCost.Text);
                Form1._instance.listOrder.Items.Add(Form1._instance.pizzaCrust);
            }
        }

        private void BtnAddNewSnack_Click(object sender, EventArgs e)
        {
            chcSnack = new CheckBox();
            chcSnack.Text = txtSnackName.Text;
            chcSnack.Size = new Size(104,33);
            chcSnack.Location = new Point(3,Form1._instance.panelSnacks.Controls.Count * chcSnack.Height);

            Form1._instance.panelSnacks.Controls.Add(chcSnack);
        }
        public void ChooseDynamicSnack()
        {
            if (chcSnack.Checked == true)
            {
                Form1._instance.snack = new ListViewItem(txtSnackName.Text);
                Form1._instance.snack.SubItems.Add("");
                Form1._instance.snack.SubItems.Add(txtSnackCost.Text);
                Form1._instance.listOrder.Items.Add(Form1._instance.snack);

            }
        }
    }
}
